import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const SITE="C:\\Projetos\\SITE-DRA-ANDRESSA";
const SISTEMA="C:\\Projetos\\SISTEMA-DRA-ANDRESSA";
const ENV=path.join(SITE,".env.local");
const FN=path.join(SISTEMA,"supabase","functions","public-booking","index.ts");

function fail(msg){console.error("\\nERRO:",msg);process.exit(1)}
function parseEnv(text){const map={};for(const raw of text.split(/\\r?\\n/)){const line=raw.trim();if(!line||line.startsWith("#"))continue;const i=line.indexOf("=");if(i<1)continue;const k=line.slice(0,i).trim();let v=line.slice(i+1).trim();if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1);map[k]=v;}return map;}

if(!fs.existsSync(ENV))fail("Não encontrei C:\\Projetos\\SITE-DRA-ANDRESSA\\.env.local");
if(!fs.existsSync(FN))fail("Não encontrei public-booking/index.ts do sistema.");

const env=parseEnv(fs.readFileSync(ENV,"utf8"));
const supabaseUrl=String(env.VITE_SUPABASE_URL||"").replace(/\/+$/,"");
const apiKey=String(env.VITE_SUPABASE_PUBLISHABLE_KEY||env.VITE_SUPABASE_ANON_KEY||env.VITE_SUPABASE_KEY||"").trim();
if(!supabaseUrl)fail("VITE_SUPABASE_URL não existe no .env.local do SITE.");
if(!apiKey)fail("Não encontrei a chave pública do Supabase no .env.local do SITE.");
let projectRef="";
try {
  const host = new URL(supabaseUrl).hostname;
  projectRef = host.split(".")[0] || "";
} catch {}
if(!projectRef)fail("VITE_SUPABASE_URL inválida.");
console.log("Projeto Supabase usado PELO SITE:",projectRef);

const stamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
const backup=path.join(SISTEMA,`.backup_public_booking_identity_v2_${stamp}`);
fs.mkdirSync(backup,{recursive:true});fs.copyFileSync(FN,path.join(backup,"index.ts"));console.log("Backup:",backup);

let src=fs.readFileSync(FN,"utf8");
const hasIdentify=/action\\s*===\\s*['\"]identify['\"]/.test(src);
const hasCheck=/action\\s*===\\s*['\"]check_existing['\"]/.test(src);
if(!hasIdentify||!hasCheck){
 const re=/^([ \\t]*)return\\s+json\\(\\{\\s*error:\\s*['\"]Ação inválida\\.['\"]\\s*\\},\\s*400\\s*\\)/m;
 const m=re.exec(src);if(!m)fail("Não encontrei o ponto final 'Ação inválida.' no public-booking.");
 const I=m[1]||"    ";
 const block=`
${I}// HOTFIX_PATIENT_IDENTITY_V2
${I}if (action === 'identify' || action === 'check_existing') {
${I}  const digits = (value: unknown) => String(value ?? '').replace(/\\D/g, '')
${I}  const cpf = digits(body.cpf)
${I}  const phone = digits(body.phone)
${I}  if (action === 'identify' && (!cpf || phone.length < 8)) return json({ found:false, message:'Informe CPF e telefone para localizar seu cadastro com segurança.' },400)
${I}  if (action === 'check_existing' && !cpf && phone.length < 8) return json({ exists:false, message:'Informe CPF ou telefone para verificar o cadastro.' })
${I}  const { data:patients, error:patientError } = await admin.from('patients').select('id,cpf,phone,whatsapp').limit(5000)
${I}  if (patientError) throw patientError
${I}  const rows = patients ?? []
${I}  if (action === 'identify') {
${I}    const found = rows.some((p:any) => digits(p.cpf)===cpf && [digits(p.phone),digits(p.whatsapp)].filter(Boolean).includes(phone))
${I}    return json({ found, message: found ? 'Cadastro localizado com sucesso.' : 'Não foi possível localizar um cadastro com esse CPF e telefone.' })
${I}  }
${I}  const cpfMatch = cpf ? rows.some((p:any)=>digits(p.cpf)===cpf) : false
${I}  const phoneMatch = phone.length>=8 ? rows.some((p:any)=>[digits(p.phone),digits(p.whatsapp)].filter(Boolean).includes(phone)) : false
${I}  const exists = cpfMatch || phoneMatch
${I}  return json({ exists, message: exists ? 'Já existe um cadastro com o CPF ou telefone informado. Use a opção “Já sou paciente”.' : 'Nenhum cadastro existente foi localizado.' })
${I}}

`;
 src=src.slice(0,m.index)+block+src.slice(m.index);fs.writeFileSync(FN,src,"utf8");console.log("OK - identify/check_existing inseridos no backend local.");
}else console.log("OK - identify/check_existing já existem localmente.");

console.log("PUBLICANDO EXPLICITAMENTE NO PROJETO DO SITE...");
const cmd=`npx supabase functions deploy public-booking --project-ref ${projectRef} --no-verify-jwt`;
const dep=spawnSync("powershell.exe",["-NoProfile","-Command",cmd],{cwd:SISTEMA,stdio:"inherit"});
if(dep.status!==0){console.error("Deploy falhou. Rode manualmente:");console.error(cmd);process.exit(2)}

async function call(body){const r=await fetch(`${supabaseUrl}/functions/v1/public-booking`,{method:"POST",headers:{"Content-Type":"application/json",apikey:apiKey,Authorization:`Bearer ${apiKey}`},body:JSON.stringify(body)});const t=await r.text();let d={};try{d=t?JSON.parse(t):{}}catch{d={raw:t}}return {status:r.status,data:d};}
const check=await call({action:"check_existing",cpf:"00000000000",phone:"00000000000"});
console.log("TESTE check_existing:",check.status,JSON.stringify(check.data));
if(String(check.data?.error||"").toLowerCase().includes("ação inválida"))fail("A função publicada ainda respondeu Ação inválida.");
const id=await call({action:"identify",cpf:"00000000000",phone:"00000000000"});
console.log("TESTE identify:",id.status,JSON.stringify(id.data));
if(String(id.data?.error||"").toLowerCase().includes("ação inválida"))fail("A função publicada ainda respondeu Ação inválida para identify.");
console.log("\\n============================================================");
console.log(" HOTFIX V2 VALIDADO AO VIVO");
console.log("============================================================");
console.log("Agora use Ctrl+F5 no site e teste Criar meu cadastro > Continuar.");
