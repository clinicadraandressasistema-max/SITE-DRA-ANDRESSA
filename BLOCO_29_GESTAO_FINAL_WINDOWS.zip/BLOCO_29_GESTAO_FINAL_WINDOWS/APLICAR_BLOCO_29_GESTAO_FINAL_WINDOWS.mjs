import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const ROOT = "C:\\Projetos\\SISTEMA-DRA-ANDRESSA";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const FILES = path.join(HERE, "files");

function fail(msg){
  console.error("\nERRO:", msg);
  process.exit(1);
}

function run(cmd,args,{allowFail=false}={}){
  console.log("\n>",cmd,...args);
  const r=spawnSync(cmd,args,{cwd:ROOT,stdio:"inherit",shell:false});
  if(r.error) console.error(r.error.message);
  if(r.status!==0 && !allowFail) fail(`${cmd} falhou com codigo ${r.status}`);
  return r.status===0;
}

if(!fs.existsSync(path.join(ROOT,"package.json")) || !fs.existsSync(path.join(ROOT,"src"))){
  fail(`Projeto nao encontrado em ${ROOT}`);
}
if(!fs.existsSync(FILES)) fail("Pasta files do BLOCO 29 nao encontrada.");

const stamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
const backup=path.join(ROOT,`.backup_bloco29_${stamp}`);
fs.mkdirSync(backup,{recursive:true});

const rels=[
  "src/pages/Finance.tsx",
  "src/pages/Sales.tsx",
  "src/pages/Contracts.tsx",
  "src/pages/ReceiptVerify.tsx",
  "supabase/migrations/20260901213000_bloco28_estornos_exclusoes_seguros.sql",
  "supabase/migrations/20260902004500_bloco29_gestao_metas_periodos.sql",
];

function copyFile(src,dst){
  fs.mkdirSync(path.dirname(dst),{recursive:true});
  fs.copyFileSync(src,dst);
}

function restore(){
  console.log("\nRestaurando arquivos anteriores...");
  for(const rel of rels){
    const saved=path.join(backup,rel);
    const target=path.join(ROOT,rel);
    if(fs.existsSync(saved)){
      copyFile(saved,target);
    }else if(rel.includes("20260901213000_bloco28") || rel.includes("20260902004500_bloco29")){
      try{fs.rmSync(target,{force:true})}catch{}
    }
  }
}

console.log("============================================================");
console.log(" BLOCO 29 - GESTAO FINAL / ESTORNOS / METRICAS / METAS");
console.log("============================================================");
console.log("Backup:",backup);

for(const rel of rels){
  const target=path.join(ROOT,rel);
  const source=path.join(FILES,rel);
  if(!fs.existsSync(source)) fail(`Arquivo do bloco ausente: ${rel}`);
  if(fs.existsSync(target)) copyFile(target,path.join(backup,rel));
  copyFile(source,target);
  console.log("OK -",rel);
}

console.log("\nVALIDANDO BUILD...");
const npm=process.platform==="win32"?"npm.cmd":"npm";
const npx=process.platform==="win32"?"npx.cmd":"npx";

const build=spawnSync(npm,["run","build"],{cwd:ROOT,stdio:"inherit",shell:false});
if(build.status!==0){
  restore();
  fail(`BUILD FALHOU. Projeto restaurado. Backup: ${backup}`);
}
console.log("\nOK - BUILD COMPLETO.");

console.log("\nATUALIZANDO BANCO SUPABASE...");
console.log("Se o Supabase perguntar se deseja aplicar as migrations, confirme Yes.");
const db=spawnSync(npx,["supabase","db","push"],{cwd:ROOT,stdio:"inherit",shell:false});
if(db.status!==0){
  console.error("\nATENCAO: o frontend ficou instalado e o BUILD passou, mas o DB PUSH falhou.");
  console.error("Nao apague os arquivos. Rode manualmente:");
  console.error(`cd "${ROOT}"`);
  console.error("npx supabase db push");
  console.error("\nMigrations:");
  console.error("supabase\\migrations\\20260901213000_bloco28_estornos_exclusoes_seguros.sql");
  console.error("supabase\\migrations\\20260902004500_bloco29_gestao_metas_periodos.sql");
  process.exit(2);
}
console.log("\nOK - BANCO ATUALIZADO.");

console.log("\nPUBLICANDO NO GITHUB...");
run("git",["add",...rels]);
const committed=run("git",["commit","-m","Bloco 29: estornos exclusoes metricas e metas"],{allowFail:true});
if(!committed) console.log("Git commit nao criou novo commit (pode nao haver diferenca ou existir outra configuracao local).");
const pushed=run("git",["push","origin","main"],{allowFail:true});
if(!pushed){
  console.log("\nATENCAO: Git push nao foi concluido. As alteracoes continuam salvas localmente.");
  console.log("Rode depois: git push origin main");
}

console.log("");
console.log("============================================================");
console.log(" BLOCO 29 CONCLUIDO");
console.log("============================================================");
console.log("Implementado:");
console.log("- Vendas: Estornar, Cancelar, Arquivar/Desativar, Reativar e Excluir");
console.log("- Filtro de vendas por periodo e status + totais do periodo");
console.log("- Financeiro: aba Estornos com auditoria");
console.log("- Recibos: estornar e depois excluir registro cancelado");
console.log("- Despesas: excluir, estornar e excluir apos estorno");
console.log("- Contratos: cancelar e excluir quando permitido");
console.log("- Metricas por periodo: vendas, recebimentos, atendimentos, despesas e estornos");
console.log("- Metas: objetivo, periodo, progresso e indicador de vitoria/alerta");
console.log("- Auditoria preservada para operacoes criticas");
console.log("");
console.log("Backup:",backup);
console.log("");
console.log("TESTES RECOMENDADOS:");
console.log("1) Vendas > venda paga > Estornar > depois Excluir se desejar");
console.log("2) Vendas > Arquivar/Desativar e depois Ver arquivados/Reativar");
console.log("3) Financeiro > Recibos > Cancelar/estornar e aba Estornos");
console.log("4) Financeiro > Metricas > escolher periodo");
console.log("5) Financeiro > Metas > criar uma meta mensal");
console.log("6) Despesas > excluir uma aberta / estornar uma paga");
console.log("7) Contratos > cancelar assinado / excluir nao assinado");
console.log("============================================================");
