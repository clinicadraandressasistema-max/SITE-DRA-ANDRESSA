import { useEffect, useState } from 'react'
import { CheckCircle2, ReceiptText, XCircle } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { money } from '../services/data'
import './Bloco27Final.css'

export default function ReceiptVerify(){
  const {code=''}=useParams()
  const [data,setData]=useState<any>(null)
  const [loading,setLoading]=useState(true)
  useEffect(()=>{void(async()=>{
    const {data:result}=await supabase.rpc('verify_payment_receipt_v27',{p_code:code})
    setData(result||{valid:false});setLoading(false)
  })()},[code])
  return <div className="b27-verify-page"><div className="b27-verify-card">
    <ReceiptText size={34}/><span className="b27-verify-kicker">VALIDAÇÃO DE RECIBO</span>
    {loading?<h1>Verificando...</h1>:data?.valid&&data?.voided?<><XCircle className="b27-bad" size={40}/><h1>Recibo cancelado / pagamento estornado</h1>
      <p>{data?.void_reason||'Este recibo foi cancelado e não comprova mais um pagamento ativo.'}</p>
      <div className="b27-verify-grid">
        <div><span>Recibo</span><strong>{data.receipt_number}</strong></div>
        <div><span>Paciente</span><strong>{data.patient_name}</strong></div>
        <div><span>Valor originalmente recebido</span><strong>{money(data.amount_received)}</strong></div>
        <div><span>Cancelado em</span><strong>{data.voided_at?new Date(data.voided_at).toLocaleString('pt-BR'):'—'}</strong></div>
      </div>
    </>:data?.valid?<><CheckCircle2 className="b27-ok" size={40}/><h1>Pagamento confirmado</h1>
      <div className="b27-verify-grid">
        <div><span>Recibo</span><strong>{data.receipt_number}</strong></div>
        <div><span>Paciente</span><strong>{data.patient_name}</strong></div>
        <div><span>Valor recebido</span><strong>{money(data.amount_received)}</strong></div>
        <div><span>Forma</span><strong>{data.method||'—'}</strong></div>
        <div><span>Data</span><strong>{new Date(data.paid_at).toLocaleString('pt-BR')}</strong></div>
        <div><span>Dias de atraso</span><strong>{data.overdue_days||0}</strong></div>
      </div>
    </>:<><XCircle className="b27-bad" size={40}/><h1>Recibo não localizado</h1></>}
  </div></div>
}
