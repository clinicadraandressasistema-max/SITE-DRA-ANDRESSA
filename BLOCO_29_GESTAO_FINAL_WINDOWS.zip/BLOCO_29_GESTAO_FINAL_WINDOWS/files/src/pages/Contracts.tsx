import { useEffect, useMemo, useState } from 'react'
import { Copy, Eye, FileCog, Pencil, Plus, Trash2, XCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Badge, EmptyState, ErrorBanner, LoadingBlock, Modal, PageHeader } from '../components/Ui'
import { dateTime, messageFromError, money } from '../services/data'

type Patient = { id: string; full_name: string }

export default function Contracts() {
  const navigate = useNavigate()
  const [contracts, setContracts] = useState<any[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [templates, setTemplates] = useState<any[]>([])
  const [sales, setSales] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [open, setOpen] = useState(false)
  const [saleId, setSaleId] = useState('')
  const [templateId, setTemplateId] = useState('')
  const [saving, setSaving] = useState(false)
  const [editing, setEditing] = useState<any | null>(null)
  const [editForm, setEditForm] = useState({ title: '', status: '' })

  async function load() {
    setLoading(true)
    const [c, p, t, s] = await Promise.all([
      supabase.from('contracts').select('id,contract_number,sale_id,patient_id,title,status,expires_at,sent_at,signed_at,created_at').order('created_at', { ascending: false }).limit(500),
      supabase.from('patients').select('id,full_name').order('full_name').limit(1000),
      supabase.from('contract_templates').select('id,name,active').eq('active', true).order('name'),
      supabase.from('sales').select('id,patient_id,status,total_amount,created_at').order('created_at', { ascending: false }).limit(500),
    ])
    const firstError = [c.error, p.error, t.error, s.error].find(Boolean)
    if (firstError) setError(messageFromError(firstError)); else setError(null)
    setContracts(c.data ?? []); setPatients((p.data ?? []) as Patient[]); setTemplates(t.data ?? []); setSales(s.data ?? []); setLoading(false)
  }
  useEffect(() => { void load() }, [])

  const patientMap = useMemo(() => Object.fromEntries(patients.map((patient) => [patient.id, patient.full_name])), [patients])
  const eligibleSales = sales.filter((sale) => !['orcamento', 'cancelado', 'rascunho'].includes(sale.status))

  async function link(contractId: string) {
    setError(null); setSuccess(null)
    const { data, error: invokeError } = await supabase.functions.invoke('contract-documents', { body: { action: 'create_link', contract_id: contractId } })
    if (invokeError || data?.error) return setError(data?.error || messageFromError(invokeError))
    const url = `${window.location.origin}/assinar/${data.token}`
    await navigator.clipboard.writeText(url); setSuccess('Novo link de assinatura copiado.')
  }

  async function createContract() {
    if (!saleId) return setError('Selecione a venda que originará o contrato.')
    setSaving(true); setError(null); setSuccess(null)
    const { data, error: invokeError } = await supabase.functions.invoke('contract-documents', { body: { action: 'generate', sale_id: saleId, template_id: templateId || null } })
    setSaving(false)
    if (invokeError || data?.error) return setError(data?.error || messageFromError(invokeError))
    setOpen(false); setSaleId(''); setTemplateId(''); setSuccess('Contrato gerado na aba Contratos.'); await load()
  }

  function openEdit(contract: any) {
    setError(null)
    setSuccess(null)
    setEditing(contract)
    setEditForm({
      title: contract.title || '',
      status: contract.status || 'rascunho',
    })
  }

  async function saveEdit() {
    if (!editing) return
    if (!editForm.title.trim()) return setError('Informe o título do contrato.')

    setSaving(true)
    setError(null)
    setSuccess(null)

    const { data, error: updateError } = await supabase.rpc('admin_update_contract', {
      p_id: editing.id,
      p_title: editForm.title.trim(),
      p_status: editForm.status || editing.status,
    })

    setSaving(false)
    if (updateError) return setError(messageFromError(updateError))
    if (!data?.ok) return setError('O banco não confirmou a alteração do contrato.')

    setEditing(null)
    setSuccess(data?.signed_locked
      ? 'Título atualizado. Como o contrato já está assinado, o status foi preservado por segurança.'
      : 'Contrato atualizado.')
    await load()
  }

  async function cancelContract(contract: any) {
    setError(null)
    setSuccess(null)
    const signed=Boolean(contract.signed_at)
    if (!window.confirm(
      signed
        ? 'Este contrato está assinado. Cancelar preservará o documento e a assinatura no histórico, mas impedirá seu uso como contrato ativo. Continuar?'
        : 'Cancelar este contrato mantendo o histórico?'
    )) return
    const reason=window.prompt('Informe o motivo do cancelamento:')
    if(!reason?.trim())return setError('Informe o motivo para continuar.')

    const { data, error: updateError } = await supabase.rpc('admin_cancel_contract_v28', {
      p_id: contract.id,
      p_reason: reason.trim(),
    })
    if (updateError) return setError(messageFromError(updateError))
    if (!data?.ok) return setError('O banco não confirmou o cancelamento.')
    setSuccess(signed
      ? 'Contrato assinado cancelado com assinatura e histórico preservados.'
      : 'Contrato cancelado com histórico preservado.')
    await load()
  }

  async function deleteContract(contract: any) {
    setError(null)
    setSuccess(null)

    if(contract.signed_at){
      return setError('Contrato assinado não é apagado. Use “Cancelar contrato” para preservar a assinatura e o histórico jurídico.')
    }
    if (!window.confirm('Excluir definitivamente este contrato não assinado? Use apenas para teste ou registro criado por engano.')) return
    const typed=window.prompt('Para confirmar a exclusão definitiva, digite EXCLUIR:')
    if(typed!=='EXCLUIR')return

    const { data, error: deleteError } = await supabase.rpc('admin_delete_contract', {
      p_id: contract.id,
      p_force: false,
    })

    if (deleteError) return setError(messageFromError(deleteError))
    if (!data?.ok) return setError('O banco não confirmou a exclusão do contrato.')

    setSuccess('Contrato excluído definitivamente. O orçamento vinculado agora pode ser excluído se não houver pagamento.')
    await load()
  }

  return <div>
    <PageHeader eyebrow="DOCUMENTOS E ASSINATURAS" title="Contratos" description="Contratos são gerados aqui a partir de vendas aprovadas."
      actions={<><button className="btn secondary" onClick={() => navigate('/contratos/modelos')}><FileCog size={15}/>Modelos e cláusulas</button><button className="btn primary" onClick={() => setOpen(true)}><Plus size={15}/>Novo contrato</button></>} />
    <ErrorBanner text={error}/>{success && <div className="success-banner">{success}</div>}
    <div className="data-card">
      {loading ? <LoadingBlock/> : contracts.length === 0 ? <EmptyState text="Nenhum contrato gerado."/> : <div className="table-wrap"><table className="data-table">
        <thead><tr><th>Contrato / paciente</th><th>Criado</th><th>Status</th><th>Ações</th></tr></thead>
        <tbody>{contracts.map((contract) => <tr key={contract.id}>
          <td><div className="cell-title"><strong>{patientMap[contract.patient_id] || contract.title || 'Paciente'}</strong><span>{contract.title || 'Contrato'} • {contract.contract_number || contract.id.slice(0,8)}</span></div></td>
          <td>{dateTime(contract.created_at)}</td><td><Badge value={contract.status}/></td>
          <td><div className="action-row"><button className="btn small secondary" onClick={() => navigate(`/contratos/${contract.id}`)}><Eye size={13}/>Ver / imprimir</button><button className="btn small secondary" onClick={() => openEdit(contract)}><Pencil size={13}/>Editar</button>{contract.status !== 'cancelado' && <button className="btn small secondary" onClick={() => void link(contract.id)}><Copy size={13}/>Link assinatura</button>}{contract.status !== 'cancelado' && <button className={contract.signed_at?'btn small danger':'btn small secondary'} onClick={() => void cancelContract(contract)}><XCircle size={13}/>{contract.signed_at?'Cancelar contrato':'Cancelar'}</button>}{!contract.signed_at&&<button className="icon-button plain" title="Excluir contrato não assinado" onClick={() => void deleteContract(contract)}><Trash2 size={14}/></button>}</div></td>
        </tr>)}</tbody>
      </table></div>}
    </div>

    <Modal open={Boolean(editing)} title="Editar contrato" onClose={() => setEditing(null)} footer={<><button className="btn secondary" onClick={() => setEditing(null)}>Cancelar</button><button className="btn primary" disabled={saving} onClick={() => void saveEdit()}>{saving ? 'Salvando...' : 'Salvar alterações'}</button></>}>
      <div className="form-grid">
        <div className="field full"><label>Título do contrato</label><input value={editForm.title} onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}/></div>
        <div className="field full"><label>Status</label><select value={editForm.status} disabled={Boolean(editing?.signed_at)} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}><option value="rascunho">Rascunho</option><option value="gerado">Gerado</option><option value="enviado">Enviado</option><option value="assinado">Assinado</option><option value="cancelado">Cancelado</option></select></div>
        {editing?.signed_at && <div className="legal-note">Este contrato já foi assinado. Para preservar a integridade da assinatura, somente o título pode ser ajustado. Se for um registro de teste, use Excluir.</div>}
        <div className="legal-note">Para alterar cláusulas e o conteúdo dos próximos contratos, use <strong>Modelos e cláusulas</strong>.</div>
      </div>
    </Modal>

    <Modal open={open} title="Novo contrato" onClose={() => setOpen(false)} footer={<><button className="btn secondary" onClick={() => setOpen(false)}>Cancelar</button><button className="btn primary" disabled={saving || !saleId} onClick={() => void createContract()}>{saving ? 'Gerando...' : 'Gerar contrato'}</button></>}>
      <div className="form-grid">
        <div className="field full"><label>Venda aprovada *</label><select value={saleId} onChange={(e) => setSaleId(e.target.value)}><option value="">Selecione...</option>{eligibleSales.map((sale) => <option key={sale.id} value={sale.id}>{patientMap[sale.patient_id] || 'Paciente'} — {money(sale.total_amount)} — {sale.status.replaceAll('_',' ')}</option>)}</select></div>
        <div className="field full"><label>Modelo de contrato</label><select value={templateId} onChange={(e) => setTemplateId(e.target.value)}><option value="">Modelo padrão do sistema</option>{templates.map((template) => <option key={template.id} value={template.id}>{template.name}</option>)}</select></div>
      </div>
    </Modal>
  </div>
}
