import { useEffect, useMemo, useState } from 'react'
import { AlertTriangle, Banknote, BellRing, CalendarRange, CheckCircle2, Copy, FileText, MessageCircle, Plus, ReceiptText, Target, Trash2, Trophy, Undo2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import QRCode from 'qrcode'
import { Badge, EmptyState, ErrorBanner, LoadingBlock, Modal, PageHeader } from '../components/Ui'
import { dateOnly, dateTime, messageFromError, money } from '../services/data'
import './Bloco27Final.css'

type Installment = {
  id:string; sale_id:string; installment_number:number; amount:number; due_date:string; paid_amount:number;
  late_fee_percent:number; monthly_interest_percent:number; grace_days:number; late_fee_paid:number; interest_paid:number;
  late_fee_waived:boolean; interest_waived:boolean; waiver_reason:string|null; payment_link:string|null; pix_copy_paste:string|null;
  status:string|null; last_reminder_at:string|null;
}
type Sale={id:string;patient_id:string;total_amount:number;paid_amount:number;entry_amount:number;status:string;created_at:string;special_discount_amount:number;referral_discount_amount:number}
type Patient={id:string;full_name:string;whatsapp:string|null;phone:string|null}
type Receipt={id:string;receipt_number:string;installment_id:string;sale_id:string;patient_id:string;amount_received:number;principal_paid:number;late_fee_paid:number;interest_paid:number;method:string|null;notes:string|null;created_at:string;verification_code?:string|null;qr_payload?:string|null;original_amount?:number|null;overdue_days?:number|null;voided_at?:string|null;void_reason?:string|null}
type Expense={id:string;description:string;supplier_name:string|null;due_date:string;total_amount:number;paid_amount:number;status:string;created_at:string;voided_at?:string|null;void_reason?:string|null}
type AuditRow={id:string;action:string;entity_type:string;entity_id:string|null;reason:string|null;details:any;created_at:string;actor_user_id:string|null}
type Goal={id:string;title:string;metric_key:string;target_value:number;period_start:string;period_end:string;active:boolean;created_at:string;current_value?:number}

function todayDate(){return new Date(new Date().toISOString().slice(0,10)+'T12:00:00')}
function parseDate(value:string){return new Date(`${value}T12:00:00`)}
function daysBetween(a:Date,b:Date){return Math.round((b.getTime()-a.getTime())/86400000)}
function financialState(i:Installment){
  const principal=Math.max(0,Number(i.amount||0)-Number(i.paid_amount||0))
  if(principal<=0.005)return {label:'pago',days:0,principal,lateFee:0,interest:0,total:0}
  const overdue=Math.max(0,daysBetween(parseDate(i.due_date),todayDate())-Number(i.grace_days||0))
  const lateTotal=overdue>0&&!i.late_fee_waived?Number(i.amount||0)*Number(i.late_fee_percent||0)/100:0
  const interestTotal=overdue>0&&!i.interest_waived?Number(i.amount||0)*Number(i.monthly_interest_percent||0)/100*(overdue/30):0
  const lateFee=Math.max(0,lateTotal-Number(i.late_fee_paid||0))
  const interest=Math.max(0,interestTotal-Number(i.interest_paid||0))
  const until=daysBetween(todayDate(),parseDate(i.due_date))
  let label='pendente'
  if(overdue>0)label='inadimplente'
  else if(until<=5)label='vence_em_5_dias'
  else if(until<=10)label='vence_em_10_dias'
  else if(Number(i.paid_amount||0)>0)label='parcial'
  return {label,days:overdue||until,principal,lateFee,interest,total:principal+lateFee+interest}
}
function escapeHtml(value:unknown){return String(value??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]||c))}
function popupDocument(title:string,body:string){
  const popup=window.open('','_blank','width=760,height=720')
  if(!popup)return false
  popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>body{font-family:Arial,sans-serif;padding:34px;color:#202124}h1{color:#8f1831;margin:0 0 6px}.brand{color:#8f1831;font-weight:800;letter-spacing:.08em}.box{border:1px solid #ddd;border-radius:12px;padding:18px;margin:20px 0}.row{display:flex;justify-content:space-between;gap:20px;padding:8px 0;border-bottom:1px solid #eee}.row:last-child{border:0}.total{font-size:22px;font-weight:800;color:#166534}.muted{color:#666;font-size:12px}.paid{display:inline-block;padding:7px 11px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:800}@media print{button{display:none}}</style></head><body>${body}<script>window.onload=()=>setTimeout(()=>window.print(),200)</script></body></html>`)
  popup.document.close();return true
}

function monthStart(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`}
function monthEnd(){const d=new Date();return new Date(d.getFullYear(),d.getMonth()+1,0).toISOString().slice(0,10)}

export default function Finance(){
  const [tab,setTab]=useState<'receivables'|'receipts'|'expenses'|'reversals'|'metrics'|'goals'>('receivables')
  const [payments,setPayments]=useState<any[]>([])
  const [receipts,setReceipts]=useState<Receipt[]>([])
  const [installments,setInstallments]=useState<Installment[]>([])
  const [sales,setSales]=useState<Sale[]>([])
  const [patients,setPatients]=useState<Patient[]>([])
  const [expenses,setExpenses]=useState<Expense[]>([])
  const [categories,setCategories]=useState<any[]>([])
  const [docSettings,setDocSettings]=useState<any>({})
  const [loading,setLoading]=useState(true)
  const [error,setError]=useState<string|null>(null)
  const [notice,setNotice]=useState<string|null>(null)
  const [expenseOpen,setExpenseOpen]=useState(false)
  const [saving,setSaving]=useState(false)
  const [expenseForm,setExpenseForm]=useState({description:'',supplier_name:'',category_id:'',due_date:'',total_amount:'',notes:''})
  const [paying,setPaying]=useState<Installment|null>(null)
  const [payForm,setPayForm]=useState({amount:'',method:'Pix',notes:'',waiveLate:false,waiveInterest:false,waiverReason:''})
  const [charging,setCharging]=useState<Installment|null>(null)
  const [chargeForm,setChargeForm]=useState({payment_link:'',pix_copy_paste:''})
  const [auditRows,setAuditRows]=useState<AuditRow[]>([])
  const [goals,setGoals]=useState<Goal[]>([])
  const [periodStart,setPeriodStart]=useState(monthStart())
  const [periodEnd,setPeriodEnd]=useState(monthEnd())
  const [metrics,setMetrics]=useState<any>({sales_count:0,sales_total:0,received_total:0,appointments_count:0,expenses_total:0,reversals_count:0,cancelled_sales:0})
  const [metricsLoading,setMetricsLoading]=useState(false)
  const [goalOpen,setGoalOpen]=useState(false)
  const [goalForm,setGoalForm]=useState({title:'',metric_key:'sales_total',target_value:'',period_start:monthStart(),period_end:monthEnd()})

  async function load(){
    setLoading(true);setError(null)
    await supabase.rpc('refresh_patient_financial_statuses')
    const [payR,receiptR,instR,saleR,patientR,expenseR,categoryR,settingsR,auditR,goalsR]=await Promise.all([
      supabase.from('payments').select('id,amount,net_amount,status,method,paid_at,created_at').order('created_at',{ascending:false}).limit(500),
      supabase.from('payment_receipts').select('*').order('created_at',{ascending:false}).limit(1000),
      supabase.from('installments').select('*').order('due_date',{ascending:true}).limit(2000),
      supabase.from('sales').select('id,patient_id,total_amount,paid_amount,entry_amount,status,created_at,special_discount_amount,referral_discount_amount').order('created_at',{ascending:false}).limit(1000),
      supabase.from('patients').select('id,full_name,whatsapp,phone').order('full_name').limit(1500),
      supabase.from('expenses').select('*').order('due_date',{ascending:false}).limit(500),
      supabase.from('financial_categories').select('id,name,category_type').eq('active',true).order('name'),
      supabase.from('clinical_document_settings').select('*').eq('id',1).maybeSingle(),
      supabase.from('admin_financial_audit').select('id,action,entity_type,entity_id,reason,details,created_at,actor_user_id').order('created_at',{ascending:false}).limit(1000),
      supabase.rpc('admin_goals_progress_v29'),
    ])
    if(payR.error)setError(messageFromError(payR.error));else setPayments(payR.data??[])
    if(receiptR.error)setError(messageFromError(receiptR.error));else setReceipts((receiptR.data??[]) as Receipt[])
    if(instR.error)setError(messageFromError(instR.error));else setInstallments((instR.data??[]) as Installment[])
    if(!saleR.error)setSales((saleR.data??[]) as Sale[]);if(!patientR.error)setPatients((patientR.data??[]) as Patient[])
    if(!expenseR.error)setExpenses((expenseR.data??[]) as Expense[]);if(!categoryR.error)setCategories(categoryR.data??[]);if(!settingsR.error)setDocSettings(settingsR.data||{})
    if(!auditR.error)setAuditRows((auditR.data??[]) as AuditRow[]);if(!goalsR.error)setGoals((goalsR.data??[]) as Goal[])
    setLoading(false)
  }
  useEffect(()=>{void load()},[])
  useEffect(()=>{void loadMetrics()},[periodStart,periodEnd])

  const saleMap=useMemo(()=>Object.fromEntries(sales.map(s=>[s.id,s])),[sales])
  const patientMap=useMemo(()=>Object.fromEntries(patients.map(p=>[p.id,p])),[patients])
  const openRows=useMemo(()=>installments.map(i=>({...i,finance:financialState(i)})).filter(x=>x.finance.principal>0.005&&!['orcamento','cancelado'].includes(saleMap[x.sale_id]?.status||'')),[installments,saleMap])
  const overdueRows=openRows.filter(x=>x.finance.label==='inadimplente')
  const urgentRows=openRows.filter(x=>x.finance.label==='vence_em_5_dias')
  const warningRows=openRows.filter(x=>x.finance.label==='vence_em_10_dias')
  const openTotal=openRows.reduce((s,x)=>s+x.finance.total,0)
  const confirmed=payments.filter(x=>x.status==='confirmado').reduce((s,x)=>s+Number(x.net_amount??x.amount??0),0)
  const receiptTotal=receipts.filter(x=>!x.voided_at).reduce((s,x)=>s+Number(x.amount_received||0),0)
  const received=confirmed+receiptTotal
  const expenseTotal=expenses.filter(x=>!x.voided_at).reduce((s,x)=>s+Number(x.total_amount||0),0)

  function patientForInstallment(i:Installment){const sale=saleMap[i.sale_id];return sale?patientMap[sale.patient_id]:undefined}
  function billingMessage(i:Installment){
    const p=patientForInstallment(i);const f=financialState(i)
    const lines=[`Olá, ${p?.full_name||'paciente'}.`,`Consta uma parcela com vencimento em ${dateOnly(i.due_date)}.`,`Valor atualizado: ${money(f.total)}.`]
    if(i.pix_copy_paste)lines.push(`Pix copia e cola: ${i.pix_copy_paste}`)
    if(i.payment_link)lines.push(`Link para pagamento: ${i.payment_link}`)
    lines.push('Em caso de dúvida, fale com a Clínica Dra. Andressa.')
    return lines.join('\n')
  }
  async function loadMetrics(){
    setMetricsLoading(true)
    const {data,error:e}=await supabase.rpc('admin_period_metrics_v29',{p_start:periodStart,p_end:periodEnd})
    setMetricsLoading(false)
    if(e){setError(messageFromError(e));return}
    setMetrics(data||{})
  }
  function metricValue(key:string){return Number(metrics?.[key]||0)}
  function metricLabel(key:string){return ({sales_total:'Vendas (R$)',sales_count:'Quantidade de vendas',received_total:'Recebido (R$)',appointments_count:'Atendimentos',expenses_total:'Despesas (R$)'} as Record<string,string>)[key]||key}
  function metricDisplay(key:string,value:number){return ['sales_total','received_total','expenses_total'].includes(key)?money(value):String(Math.round(value))}
  async function saveGoal(){
    if(!goalForm.title.trim()||!goalForm.target_value||Number(goalForm.target_value)<=0)return setError('Preencha o nome e uma meta maior que zero.')
    setSaving(true);setError(null)
    const {data,error:e}=await supabase.rpc('admin_save_goal_v29',{p_id:null,p_title:goalForm.title.trim(),p_metric_key:goalForm.metric_key,p_target_value:Number(goalForm.target_value),p_period_start:goalForm.period_start,p_period_end:goalForm.period_end})
    setSaving(false);if(e)return setError(messageFromError(e));if(!data?.ok)return setError('Não foi possível salvar a meta.')
    setGoalOpen(false);setGoalForm({title:'',metric_key:'sales_total',target_value:'',period_start:monthStart(),period_end:monthEnd()});setNotice('Meta salva.');await load()
  }
  async function deleteGoal(goal:Goal){
    if(!window.confirm(`Excluir a meta "${goal.title}"?`))return
    const {data,error:e}=await supabase.rpc('admin_delete_goal_v29',{p_id:goal.id})
    if(e)return setError(messageFromError(e));if(!data?.ok)return setError('Não foi possível excluir a meta.');setNotice('Meta excluída.');await load()
  }
  async function deleteVoidedReceipt(item:Receipt){
    if(!item.voided_at)return
    if(!window.confirm(`Excluir definitivamente o recibo cancelado ${item.receipt_number}? O estorno financeiro será preservado na auditoria.`))return
    const typed=window.prompt('Para confirmar, digite EXCLUIR:');if(typed!=='EXCLUIR')return
    const {data,error:e}=await supabase.rpc('admin_delete_voided_receipt_v29',{p_id:item.id})
    if(e)return setError(messageFromError(e));if(!data?.ok)return setError('O banco não confirmou a exclusão.');setNotice('Recibo cancelado excluído; auditoria preservada.');await load()
  }
  async function deleteVoidedExpense(item:Expense){
    if(!item.voided_at)return
    if(!window.confirm(`Excluir definitivamente a despesa estornada "${item.description}"?`))return
    const typed=window.prompt('Para confirmar, digite EXCLUIR:');if(typed!=='EXCLUIR')return
    const {data,error:e}=await supabase.rpc('admin_delete_voided_expense_v29',{p_id:item.id})
    if(e)return setError(messageFromError(e));if(!data?.ok)return setError('O banco não confirmou a exclusão.');setNotice('Despesa estornada excluída; auditoria preservada.');await load()
  }
  function openPayment(i:Installment){
    const f=financialState(i);setPaying(i);setPayForm({amount:f.total.toFixed(2),method:'Pix',notes:'',waiveLate:false,waiveInterest:false,waiverReason:''})
  }
  async function registerPayment(){
    if(!paying)return
    setSaving(true);setError(null);setNotice(null)
    const {data,error:e}=await supabase.rpc('register_installment_payment',{
      p_installment_id:paying.id,p_amount_received:Number(payForm.amount||0),p_method:payForm.method,
      p_notes:payForm.notes||null,p_waive_late_fee:payForm.waiveLate,p_waive_interest:payForm.waiveInterest,
      p_waiver_reason:payForm.waiverReason||null,
    })
    setSaving(false)
    if(e)return setError(messageFromError(e))
    setPaying(null)
    setNotice(`Pagamento registrado. Recibo ${data?.receipt_number||''} gerado automaticamente.`)
    await load()
    if(data?.receipt_id){
      const {data:receipt}=await supabase.from('payment_receipts').select('*').eq('id',data.receipt_id).maybeSingle()
      if(receipt){setTab('receipts');setTimeout(()=>void printReceipt(receipt as Receipt),250)}
    }
  }
  function openCharge(i:Installment){setCharging(i);setChargeForm({payment_link:i.payment_link||'',pix_copy_paste:i.pix_copy_paste||''})}
  async function saveCharge(){
    if(!charging)return
    setSaving(true)
    const {error:e}=await supabase.rpc('set_installment_payment_channels',{p_installment_id:charging.id,p_payment_link:chargeForm.payment_link||null,p_pix_copy_paste:chargeForm.pix_copy_paste||null})
    setSaving(false);if(e)return setError(messageFromError(e))
    setCharging(null);setNotice('Dados de cobrança atualizados.');await load()
  }
  async function createExpense(){
    if(!expenseForm.description.trim()||!expenseForm.due_date||!expenseForm.total_amount)return setError('Preencha descrição, vencimento e valor.')
    setSaving(true)
    const {error:e}=await supabase.from('expenses').insert({description:expenseForm.description.trim(),supplier_name:expenseForm.supplier_name.trim()||null,category_id:expenseForm.category_id||null,due_date:expenseForm.due_date,total_amount:Number(expenseForm.total_amount),notes:expenseForm.notes.trim()||null})
    setSaving(false);if(e)return setError(messageFromError(e))
    setExpenseOpen(false);setExpenseForm({description:'',supplier_name:'',category_id:'',due_date:'',total_amount:'',notes:''});await load()
  }


  async function deleteOrVoidExpense(item:Expense){
    setError(null)
    setNotice(null)
    if(item.voided_at)return

    const paid=Number(item.paid_amount||0)>0
    const action=paid?'ESTORNAR':'EXCLUIR'
    const question=paid
      ? `Estornar a despesa "${item.description}"? O registro ficará no histórico como estornado.`
      : `Excluir definitivamente a despesa "${item.description}"?`

    if(!window.confirm(question))return

    const reason=window.prompt(
      paid
        ? 'Informe o motivo do estorno:'
        : 'Informe o motivo da exclusão (para auditoria):'
    )
    if(!reason?.trim())return setError('Informe o motivo para continuar.')

    const typed=window.prompt(`Para confirmar, digite ${action}:`)
    if(typed!==action)return

    const {data,error:e}=await supabase.rpc(
      'admin_delete_or_void_expense_v28',
      {p_id:item.id,p_reason:reason.trim()}
    )
    if(e)return setError(messageFromError(e))
    if(!data?.ok)return setError('O banco não confirmou a operação.')

    setNotice(paid
      ? `Despesa "${item.description}" estornada com histórico preservado.`
      : `Despesa "${item.description}" excluída.`)
    await load()
  }

  async function voidReceipt(item:Receipt){
    setError(null)
    setNotice(null)
    if(item.voided_at)return

    if(!window.confirm(
      `Cancelar o recibo ${item.receipt_number} e ESTORNAR o pagamento de ${money(item.amount_received)}? `+
      'A parcela voltará para Contas a receber e o recibo permanecerá no histórico como cancelado.'
    ))return

    const reason=window.prompt('Informe o motivo do cancelamento/estorno:')
    if(!reason?.trim())return setError('Informe o motivo do estorno.')

    const typed=window.prompt('Para confirmar o estorno, digite ESTORNAR:')
    if(typed!=='ESTORNAR')return

    setSaving(true)
    const {data,error:e}=await supabase.rpc(
      'admin_void_receipt_v28',
      {p_receipt_id:item.id,p_reason:reason.trim()}
    )
    setSaving(false)

    if(e)return setError(messageFromError(e))
    if(!data?.ok)return setError('O banco não confirmou o estorno.')

    setNotice(`Recibo ${item.receipt_number} cancelado e pagamento estornado. A parcela voltou para Contas a receber.`)
    await load()
  }

  async function sendWhatsapp(i:Installment){
    const p=patientForInstallment(i)
    const phone=String(p?.whatsapp||p?.phone||'').replace(/\D/g,'')

    if(!phone){
      setError('Paciente sem WhatsApp/telefone cadastrado.')
      return
    }

    const url=`https://wa.me/${phone}?text=${encodeURIComponent(billingMessage(i))}`

    window.open(url,'_blank','noopener,noreferrer')

    const {error:e}=await supabase
      .from('installments')
      .update({last_reminder_at:new Date().toISOString()})
      .eq('id',i.id)

    if(e){
      setError(messageFromError(e))
      return
    }

    setNotice(`Contato de cobrança registrado para ${p?.full_name||'o paciente'}.`)
    await load()
  }
  function printCharge(i:Installment){
    const p=patientForInstallment(i);const f=financialState(i)
    popupDocument('Cobrança',`<div class="brand">CLÍNICA DRA. ANDRESSA</div><h1>Aviso de cobrança</h1><p class="muted">Documento de cobrança sem valor fiscal.</p><div class="box"><div class="row"><span>Paciente</span><strong>${escapeHtml(p?.full_name||'Paciente')}</strong></div><div class="row"><span>Parcela</span><strong>${i.installment_number}</strong></div><div class="row"><span>Vencimento</span><strong>${escapeHtml(dateOnly(i.due_date))}</strong></div><div class="row"><span>Principal em aberto</span><strong>${escapeHtml(money(f.principal))}</strong></div><div class="row"><span>Multa</span><strong>${escapeHtml(money(f.lateFee))}</strong></div><div class="row"><span>Juros</span><strong>${escapeHtml(money(f.interest))}</strong></div><div class="row"><span>Total atualizado</span><strong class="total">${escapeHtml(money(f.total))}</strong></div></div>${i.pix_copy_paste?`<div class="box"><strong>Pix copia e cola</strong><p>${escapeHtml(i.pix_copy_paste)}</p></div>`:''}${i.payment_link?`<div class="box"><strong>Link de pagamento</strong><p>${escapeHtml(i.payment_link)}</p></div>`:''}`)
  }
  function receiptValidationUrl(r:Receipt){
    const base=String(docSettings.validation_base_url||window.location.origin).replace(/\/$/,'')
    return `${base}/validar-recibo/${encodeURIComponent(r.verification_code||'')}`
  }
  async function printReceipt(r:Receipt){
    const p=patientMap[r.patient_id]
    const sale=saleMap[r.sale_id]
    const inst=installments.find(i=>i.id===r.installment_id)
    const settled=Boolean(sale)&&Number(sale.paid_amount||0)>=Number(sale.total_amount||0)-0.005
    const qr=await QRCode.toDataURL(receiptValidationUrl(r),{width:180,margin:1})
    const logo=docSettings.logo_data_url||'/media/papelaria/logo.png'
    const doctorSig=docSettings.doctor_signature_data_url||docSettings.doctor_rubric_data_url||''
    const stamp=docSettings.clinic_stamp_data_url||docSettings.clinic_signature_data_url||''
    const original=Number(r.original_amount??inst?.amount??r.amount_received??0)
    const popup=window.open('','_blank','width=900,height=820')
    if(!popup)return setError('O navegador bloqueou a janela do recibo.')
    popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(r.receipt_number)}</title><style>
      @page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Arial;color:#25252a;background:#ddd}
      .page{position:relative;width:210mm;height:297mm;margin:auto;background:#fff;padding:18mm 20mm;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      header{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #8f1c35;padding-bottom:6mm}
      header img{max-width:55mm;max-height:22mm;object-fit:contain}header div{text-align:right;font-size:8pt;color:#666}header strong{display:block;color:#8f1c35;font-size:11pt}
      h1{font-family:Georgia,serif;color:#691428;text-align:center;font-size:24pt;margin:14mm 0 3mm}.status{text-align:center}.status span{display:inline-block;padding:2.5mm 5mm;border-radius:99px;background:#e8f7ee;color:#166534;font-weight:800;font-size:8pt}.voided{margin-top:6mm;border:2px solid #b91c1c;background:#fff1f2;color:#991b1b;padding:4mm;border-radius:3mm;text-align:center;font-weight:800}
      .box{border:1px solid #eadde0;border-radius:4mm;padding:5mm;margin-top:9mm}.row{display:flex;justify-content:space-between;gap:8mm;padding:3mm 0;border-bottom:1px solid #eee}.row:last-child{border:0}.row span{color:#666}.total{font-size:16pt;color:#166534}
      .signatures{position:absolute;left:20mm;bottom:36mm;display:flex;gap:12mm;align-items:end}.signatures img{max-width:45mm;max-height:20mm;object-fit:contain}.signature{text-align:center;font-size:7pt;min-width:48mm}.signature strong{display:block}
      .verify{position:absolute;right:20mm;bottom:25mm;display:flex;align-items:center;gap:3mm;font-size:6pt}.verify img{width:25mm;height:25mm}.verify div{display:flex;flex-direction:column}.verify strong{color:#8f1c35;font-size:7pt}
      footer{position:absolute;left:20mm;right:20mm;bottom:11mm;text-align:center;border-top:1px solid #eadde0;padding-top:3mm;color:#777;font-size:6.5pt}
      @media print{body{background:#fff}.page{margin:0}}
    </style></head><body><div class="page">
      <header><img src="${escapeHtml(logo)}"><div><strong>${escapeHtml(docSettings.clinic_name||'Clínica Dra. Andressa')}</strong>${escapeHtml(docSettings.clinic_cnpj?`CNPJ ${docSettings.clinic_cnpj}`:'')}<br>${escapeHtml(docSettings.clinic_address||'')}</div></header>
      <h1>Recibo de pagamento</h1><div class="status"><span>${r.voided_at?'RECIBO CANCELADO / ESTORNADO':settled?'VENDA QUITADA':'PAGAMENTO REGISTRADO'}</span></div>
      ${r.voided_at?`<div class="voided">ESTE RECIBO FOI CANCELADO E O PAGAMENTO ESTORNADO.<br><small>${escapeHtml(r.void_reason||'')}</small></div>`:''}
      <div class="box">
        <div class="row"><span>Recibo</span><strong>${escapeHtml(r.receipt_number)}</strong></div>
        <div class="row"><span>Paciente</span><strong>${escapeHtml(p?.full_name||'Paciente')}</strong></div>
        <div class="row"><span>Data e hora</span><strong>${escapeHtml(dateTime(r.created_at))}</strong></div>
        <div class="row"><span>Forma de pagamento</span><strong>${escapeHtml(r.method||'—')}</strong></div>
        <div class="row"><span>Valor original da parcela</span><strong>${escapeHtml(money(original))}</strong></div>
        <div class="row"><span>Dias de atraso</span><strong>${Number(r.overdue_days||0)}</strong></div>
        <div class="row"><span>Principal pago</span><strong>${escapeHtml(money(r.principal_paid))}</strong></div>
        <div class="row"><span>Multa paga</span><strong>${escapeHtml(money(r.late_fee_paid))}</strong></div>
        <div class="row"><span>Juros pagos</span><strong>${escapeHtml(money(r.interest_paid))}</strong></div>
        <div class="row"><span>Total efetivamente recebido</span><strong class="total">${escapeHtml(money(r.amount_received))}</strong></div>
      </div>
      ${r.notes?`<div class="box"><strong>Observações</strong><p>${escapeHtml(r.notes)}</p></div>`:''}
      <div class="signatures">
        ${doctorSig?`<div class="signature"><img src="${doctorSig}"><strong>${escapeHtml(docSettings.doctor_name||"Dra. Andressa Dall'Armi")}</strong><span>${escapeHtml(docSettings.crm||'CRM 28292 PR')} · ${escapeHtml(docSettings.rqe||'RQE 2826')}</span></div>`:''}
        ${stamp?`<div class="signature"><img src="${stamp}"><strong>Clínica</strong></div>`:''}
      </div>
      <div class="verify"><img src="${qr}"><div><strong>Validação digital</strong><span>${escapeHtml(r.verification_code||'')}</span><small>Leia o QR Code para validar.</small></div></div>
      <footer>${escapeHtml(docSettings.footer_text||'Recibo de controle interno. Para documento fiscal, utilize o documento fiscal aplicável.')}</footer>
    </div><script>window.addEventListener('load',async()=>{await Promise.all([...document.images].map(i=>i.complete&&i.decode?i.decode().catch(()=>{}):new Promise(r=>{i.onload=r;i.onerror=r})));setTimeout(()=>window.print(),200)})</script></body></html>`)
    popup.document.close()
  }
  function sendReceiptWhatsapp(r:Receipt){
    const p=patientMap[r.patient_id]
    const phone=String(p?.whatsapp||p?.phone||'').replace(/\D/g,'')
    if(!phone)return setError('Paciente sem WhatsApp/telefone cadastrado.')
    const text=[`Olá, ${p?.full_name||''}.`,`Pagamento registrado pela Clínica Dra. Andressa.`,`Recibo: ${r.receipt_number}`,`Valor: ${money(r.amount_received)}`,`Validação: ${receiptValidationUrl(r)}`].join('\n')
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`,'_blank','noopener,noreferrer')
  }

  return <div>
    <PageHeader eyebrow="CONTROLE FINANCEIRO" title="Financeiro"
      description="Contas a receber, vencimentos, inadimplência, pagamentos, recibos e despesas."
      actions={<button className="btn primary" onClick={()=>setExpenseOpen(true)}><Plus size={15}/>Nova despesa</button>}/>
    <ErrorBanner text={error}/>{notice&&<div className="success-banner">{notice}</div>}
    <div className="metric-row">
      <div className="mini-metric"><span>Recebido registrado</span><strong>{money(received)}</strong></div>
      <div className="mini-metric"><span>Em aberto atualizado</span><strong>{money(openTotal)}</strong></div>
      <div className="mini-metric"><span>Vencidos</span><strong>{overdueRows.length}</strong></div>
      <div className="mini-metric"><span>Vencem em 5 dias</span><strong>{urgentRows.length}</strong></div>
      <div className="mini-metric"><span>Vencem em 10 dias</span><strong>{warningRows.length}</strong></div>
    </div>

    {(overdueRows.length>0 || urgentRows.length>0 || warningRows.length>0) && (
      <div style={{
        margin:'16px 0',
        padding:'16px 18px',
        borderRadius:14,
        border:'1px solid #fed7aa',
        background:'#fff7ed',
        color:'#9a3412',
        fontWeight:700
      }}>
        🔔 Atenção:
        {' '}{overdueRows.length} pagamento(s) vencido(s),
        {' '}{urgentRows.length} vencendo em até 5 dias e
        {' '}{warningRows.length} vencendo em até 10 dias.
        Acesse as parcelas abaixo para entrar em contato com os pacientes.
      </div>
    )}

    <div className="catalog-tabs">
      <button className={tab==='receivables'?'active':''} onClick={()=>setTab('receivables')}><BellRing size={16}/>Contas a receber</button>
      <button className={tab==='receipts'?'active':''} onClick={()=>setTab('receipts')}><ReceiptText size={16}/>Recibos</button>
      <button className={tab==='expenses'?'active':''} onClick={()=>setTab('expenses')}><Banknote size={16}/>Despesas</button>
      <button className={tab==='reversals'?'active':''} onClick={()=>setTab('reversals')}><Undo2 size={16}/>Estornos</button>
      <button className={tab==='metrics'?'active':''} onClick={()=>setTab('metrics')}><CalendarRange size={16}/>Métricas</button>
      <button className={tab==='goals'?'active':''} onClick={()=>setTab('goals')}><Target size={16}/>Metas</button>
    </div>

    {tab==='receivables'&&<section className="data-card">
      {loading?<LoadingBlock/>:openRows.length===0?<EmptyState text="Nenhuma parcela em aberto."/>:<div className="table-wrap"><table className="data-table">
        <thead><tr><th>Paciente</th><th>Parcela</th><th>Vencimento</th><th>Principal</th><th>Atualizado</th><th>Status</th><th>Último contato</th><th>Ações</th></tr></thead>
        <tbody>{openRows.map(i=>{const p=patientForInstallment(i);return <tr key={i.id} style={i.finance.label==='inadimplente'?{background:'#fff1f2'}:i.finance.label==='vence_em_5_dias'?{background:'#fff7ed'}:undefined}>
          <td><div className="cell-title"><strong>{p?.full_name||'Paciente'}</strong><span>{p?.whatsapp||p?.phone||'Sem telefone'}</span></div></td>
          <td>{i.installment_number===0?'Entrada':`#${i.installment_number}`}</td><td>{dateOnly(i.due_date)}</td><td>{money(i.finance.principal)}</td><td><strong>{money(i.finance.total)}</strong></td>
          <td><Badge value={i.finance.label}/></td>
          <td>{i.last_reminder_at?dateTime(i.last_reminder_at):'Não contatado'}</td>
          <td><div className="action-row">
            <button className="btn small secondary" onClick={()=>openCharge(i)}><FileText size={13}/>Cobrança</button>
            <button className="btn small secondary" onClick={()=>void sendWhatsapp(i)}><MessageCircle size={13}/>WhatsApp</button>
            <button className="btn small primary" onClick={()=>openPayment(i)}><CheckCircle2 size={13}/>Baixar pagamento</button>
          </div></td>
        </tr>})}</tbody>
      </table></div>}
    </section>}

    {tab==='receipts'&&<section className="data-card">
      {loading?<LoadingBlock/>:receipts.length===0?<EmptyState text="Nenhum recibo gerado ainda."/>:<div className="table-wrap"><table className="data-table">
        <thead><tr><th>Recibo</th><th>Paciente</th><th>Data</th><th>Forma</th><th>Valor</th><th>Status</th><th>Ações</th></tr></thead>
        <tbody>{receipts.map(r=><tr key={r.id} style={r.voided_at?{opacity:.68}:undefined}>
          <td><div className="cell-title"><strong>{r.receipt_number}</strong>{r.voided_at&&<span>{r.void_reason||'Recibo cancelado / pagamento estornado'}</span>}</div></td>
          <td>{patientMap[r.patient_id]?.full_name||'Paciente'}</td><td>{dateTime(r.created_at)}</td><td>{r.method||'—'}</td><td>{money(r.amount_received)}</td>
          <td><Badge value={r.voided_at?'cancelado':'pago'}/></td>
          <td><div className="action-row">
            <button className="btn small secondary" onClick={()=>void printReceipt(r)}><ReceiptText size={13}/>Ver / imprimir</button>
            {!r.voided_at&&<button className="btn small secondary" onClick={()=>sendReceiptWhatsapp(r)}><MessageCircle size={13}/>WhatsApp</button>}
            {!r.voided_at&&<button className="btn small danger" disabled={saving} onClick={()=>void voidReceipt(r)}><Undo2 size={13}/>Cancelar / estornar</button>}
            {r.voided_at&&<button className="btn small danger" disabled={saving} onClick={()=>void deleteVoidedReceipt(r)}><Trash2 size={13}/>Excluir</button>}
          </div></td>
        </tr>)}</tbody>
      </table></div>}
    </section>}

    {tab==='expenses'&&<section className="data-card">
      <div style={{padding:18,borderBottom:'1px solid var(--border)'}}><strong>Despesas cadastradas — {money(expenseTotal)}</strong></div>
      {loading?<LoadingBlock/>:expenses.length===0?<EmptyState text="Nenhuma despesa cadastrada."/>:<div className="table-wrap"><table className="data-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Vencimento</th>
            <th>Valor</th>
            <th>Status</th>
            <th>Ações</th>
          </tr>
        </thead>

        <tbody>
          {expenses.map(i=>
            <tr key={i.id}>
              <td>
                <div className="cell-title">
                  <strong>{i.description}</strong>
                  <span>{i.supplier_name||'Sem fornecedor'}</span>
                </div>
              </td>

              <td>{dateOnly(i.due_date)}</td>

              <td>{money(i.total_amount)}</td>

              <td>
                <Badge value={i.voided_at?'estornada':i.status}/>
              </td>

              <td>
                {i.voided_at
                  ? <div className="action-row"><span style={{fontSize:12,color:'var(--text-muted)'}} title={i.void_reason||''}>Estornada</span><button className="btn small danger" onClick={()=>void deleteVoidedExpense(i)}><Trash2 size={13}/>Excluir</button></div>
                  : <button
                      className="btn small danger"
                      onClick={()=>void deleteOrVoidExpense(i)}
                    >
                      {Number(i.paid_amount||0)>0?<Undo2 size={13}/>:<Trash2 size={13}/>}
                      {Number(i.paid_amount||0)>0?'Estornar':'Excluir'}
                    </button>}
              </td>
            </tr>
          )}
        </tbody>
      </table></div>}
    </section>}

    {tab==='reversals'&&<section className="data-card">
      <div style={{padding:18,borderBottom:'1px solid var(--border)'}}><strong>Histórico de estornos, cancelamentos e exclusões</strong><div style={{fontSize:12,color:'var(--text-muted)',marginTop:4}}>O histórico de auditoria permanece mesmo quando um registro de teste é excluído.</div></div>
      {auditRows.length===0?<EmptyState text="Nenhum estorno ou cancelamento registrado."/>:<div className="table-wrap"><table className="data-table"><thead><tr><th>Data</th><th>Ação</th><th>Tipo</th><th>Motivo</th><th>Detalhes</th></tr></thead><tbody>{auditRows.filter(a=>/void|revers|estorn|cancel|delete/i.test(a.action)).map(a=><tr key={a.id}><td>{dateTime(a.created_at)}</td><td><Badge value={a.action}/></td><td>{a.entity_type}</td><td>{a.reason||'—'}</td><td style={{maxWidth:360,whiteSpace:'normal'}}>{a.details?JSON.stringify(a.details):'—'}</td></tr>)}</tbody></table></div>}
    </section>}

    {tab==='metrics'&&<section className="data-card" style={{padding:18}}>
      <div style={{display:'flex',gap:12,alignItems:'end',flexWrap:'wrap',marginBottom:18}}><div className="field"><label>De</label><input type="date" value={periodStart} onChange={e=>setPeriodStart(e.target.value)}/></div><div className="field"><label>Até</label><input type="date" value={periodEnd} onChange={e=>setPeriodEnd(e.target.value)}/></div><button className="btn secondary" onClick={()=>void loadMetrics()}><CalendarRange size={14}/>Atualizar período</button></div>
      {metricsLoading?<LoadingBlock/>:<><div className="metric-row"><div className="mini-metric"><span>Vendas no período</span><strong>{metricDisplay('sales_total',metricValue('sales_total'))}</strong><small>{metricValue('sales_count')} venda(s)</small></div><div className="mini-metric"><span>Recebido</span><strong>{metricDisplay('received_total',metricValue('received_total'))}</strong></div><div className="mini-metric"><span>Atendimentos</span><strong>{metricDisplay('appointments_count',metricValue('appointments_count'))}</strong></div><div className="mini-metric"><span>Despesas</span><strong>{metricDisplay('expenses_total',metricValue('expenses_total'))}</strong></div><div className="mini-metric"><span>Estornos</span><strong>{metricValue('reversals_count')}</strong></div></div><div style={{marginTop:16,padding:16,border:'1px solid var(--border)',borderRadius:14}}><strong>Resumo gerencial</strong><p style={{marginBottom:0,color:'var(--text-muted)'}}>Período de {dateOnly(periodStart)} a {dateOnly(periodEnd)} · {metricValue('cancelled_sales')} venda(s) cancelada(s).</p></div></>}
    </section>}

    {tab==='goals'&&<section className="data-card">
      <div style={{padding:18,borderBottom:'1px solid var(--border)',display:'flex',justifyContent:'space-between',gap:12,alignItems:'center',flexWrap:'wrap'}}><div><strong>Metas da clínica</strong><div style={{fontSize:12,color:'var(--text-muted)',marginTop:4}}>Acompanhe metas mensais ou por qualquer período.</div></div><button className="btn primary" onClick={()=>setGoalOpen(true)}><Plus size={14}/>Nova meta</button></div>
      {goals.length===0?<EmptyState text="Nenhuma meta cadastrada."/>:<div style={{padding:18,display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:14}}>{goals.map(g=>{const current=Number(g.current_value||0);const pct=Math.min(100,Math.max(0,(current/Math.max(0.0001,Number(g.target_value||0)))*100));const hit=current>=Number(g.target_value||0);return <div key={g.id} style={{border:'1px solid var(--border)',borderRadius:16,padding:18,background:hit?'#f0fdf4':'#fff'}}><div style={{display:'flex',justifyContent:'space-between',gap:10,alignItems:'center'}}><div><small style={{color:'var(--text-muted)'}}>{metricLabel(g.metric_key)}</small><h3 style={{margin:'4px 0'}}>{g.title}</h3></div>{hit?<Trophy size={28}/>:<AlertTriangle size={28}/>}</div><div style={{fontSize:13,color:'var(--text-muted)',marginBottom:10}}>{dateOnly(g.period_start)} até {dateOnly(g.period_end)}</div><strong>{metricDisplay(g.metric_key,current)} / {metricDisplay(g.metric_key,Number(g.target_value||0))}</strong><div style={{height:9,borderRadius:999,background:'#eee',overflow:'hidden',margin:'12px 0'}}><div style={{width:`${pct}%`,height:'100%',background:hit?'#16a34a':'#9f1733'}}/></div><div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><span style={{fontWeight:800,color:hit?'#166534':'#9f1733'}}>{hit?'META BATIDA 🎉':`${pct.toFixed(0)}% concluído`}</span><button className="icon-button plain" title="Excluir meta" onClick={()=>void deleteGoal(g)}><Trash2 size={15}/></button></div></div>})}</div>}
    </section>}

    <Modal open={Boolean(paying)} title={paying?'Baixar pagamento da parcela '+paying.installment_number:'Baixar pagamento'} onClose={()=>setPaying(null)} wide
      footer={<><button className="btn secondary" onClick={()=>setPaying(null)}>Cancelar</button><button className="btn primary" disabled={saving} onClick={()=>void registerPayment()}>{saving?'Salvando...':'Registrar e gerar recibo'}</button></>}>
      {paying&&<><div className="metric-row"><div className="mini-metric"><span>Principal em aberto</span><strong>{money(financialState(paying).principal)}</strong></div><div className="mini-metric"><span>Multa</span><strong>{money(financialState(paying).lateFee)}</strong></div><div className="mini-metric"><span>Juros</span><strong>{money(financialState(paying).interest)}</strong></div><div className="mini-metric"><span>Total atual</span><strong>{money(financialState(paying).total)}</strong></div></div>
      <div className="form-grid">
        <div className="field"><label>Valor recebido *</label><input type="number" min="0.01" step="0.01" value={payForm.amount} onChange={e=>setPayForm({...payForm,amount:e.target.value})}/></div>
        <div className="field"><label>Forma</label><select value={payForm.method} onChange={e=>setPayForm({...payForm,method:e.target.value})}><option>Pix</option><option>Dinheiro</option><option>Cartão de crédito</option><option>Cartão de débito</option><option>Transferência</option><option>Boleto</option><option>Outro</option></select></div>
        <label><input type="checkbox" checked={payForm.waiveLate} onChange={e=>setPayForm({...payForm,waiveLate:e.target.checked})}/> Retirar multa</label>
        <label><input type="checkbox" checked={payForm.waiveInterest} onChange={e=>setPayForm({...payForm,waiveInterest:e.target.checked})}/> Retirar juros</label>
        {(payForm.waiveLate||payForm.waiveInterest)&&<div className="field full"><label>Motivo da condição especial *</label><input value={payForm.waiverReason} onChange={e=>setPayForm({...payForm,waiverReason:e.target.value})}/></div>}
        <div className="field full"><label>Observações</label><textarea value={payForm.notes} onChange={e=>setPayForm({...payForm,notes:e.target.value})}/></div>
      </div></>}
    </Modal>

    <Modal open={Boolean(charging)} title="Cobrança / meios de pagamento" onClose={()=>setCharging(null)} wide
      footer={<><button className="btn secondary" onClick={()=>setCharging(null)}>Fechar</button>{charging&&<button className="btn secondary" onClick={()=>printCharge(charging)}><FileText size={14}/>Imprimir cobrança</button>}<button className="btn primary" disabled={saving} onClick={()=>void saveCharge()}>Salvar</button></>}>
      <p style={{marginTop:0,color:'var(--text-muted)'}}>Enquanto não houver integração automática com um gateway, você pode cadastrar aqui o link gerado pela maquininha/gateway e o Pix copia e cola.</p>
      <div className="form-grid">
        <div className="field full"><label>Link de pagamento</label><div style={{display:'flex',gap:8}}><input value={chargeForm.payment_link} onChange={e=>setChargeForm({...chargeForm,payment_link:e.target.value})}/><button className="btn secondary" onClick={()=>navigator.clipboard.writeText(chargeForm.payment_link)}><Copy size={13}/></button></div></div>
        <div className="field full"><label>Pix copia e cola</label><div style={{display:'flex',gap:8}}><textarea value={chargeForm.pix_copy_paste} onChange={e=>setChargeForm({...chargeForm,pix_copy_paste:e.target.value})}/><button className="btn secondary" onClick={()=>navigator.clipboard.writeText(chargeForm.pix_copy_paste)}><Copy size={13}/></button></div></div>
      </div>
    </Modal>

    <Modal open={expenseOpen} title="Nova despesa" onClose={()=>setExpenseOpen(false)}
      footer={<><button className="btn secondary" onClick={()=>setExpenseOpen(false)}>Cancelar</button><button className="btn primary" disabled={saving} onClick={()=>void createExpense()}>{saving?'Salvando...':'Salvar despesa'}</button></>}>
      <div className="form-grid">
        <div className="field full"><label>Descrição *</label><input value={expenseForm.description} onChange={e=>setExpenseForm({...expenseForm,description:e.target.value})}/></div>
        <div className="field"><label>Fornecedor</label><input value={expenseForm.supplier_name} onChange={e=>setExpenseForm({...expenseForm,supplier_name:e.target.value})}/></div>
        <div className="field"><label>Categoria</label><select value={expenseForm.category_id} onChange={e=>setExpenseForm({...expenseForm,category_id:e.target.value})}><option value="">Sem categoria</option>{categories.map(i=><option key={i.id} value={i.id}>{i.name}</option>)}</select></div>
        <div className="field"><label>Vencimento *</label><input type="date" value={expenseForm.due_date} onChange={e=>setExpenseForm({...expenseForm,due_date:e.target.value})}/></div>
        <div className="field"><label>Valor *</label><input type="number" min="0" step="0.01" value={expenseForm.total_amount} onChange={e=>setExpenseForm({...expenseForm,total_amount:e.target.value})}/></div>
        <div className="field full"><label>Observações</label><textarea value={expenseForm.notes} onChange={e=>setExpenseForm({...expenseForm,notes:e.target.value})}/></div>
      </div>
    </Modal>

    <Modal open={goalOpen} title="Nova meta" onClose={()=>setGoalOpen(false)}
      footer={<><button className="btn secondary" onClick={()=>setGoalOpen(false)}>Cancelar</button><button className="btn primary" disabled={saving} onClick={()=>void saveGoal()}>{saving?'Salvando...':'Salvar meta'}</button></>}>
      <div className="form-grid"><div className="field full"><label>Nome da meta *</label><input value={goalForm.title} onChange={e=>setGoalForm({...goalForm,title:e.target.value})} placeholder="Ex.: Faturar R$ 50 mil em setembro"/></div><div className="field"><label>Indicador</label><select value={goalForm.metric_key} onChange={e=>setGoalForm({...goalForm,metric_key:e.target.value})}><option value="sales_total">Vendas em R$</option><option value="sales_count">Quantidade de vendas</option><option value="received_total">Recebimentos em R$</option><option value="appointments_count">Atendimentos</option><option value="expenses_total">Despesas em R$</option></select></div><div className="field"><label>Meta *</label><input type="number" min="0.01" step="0.01" value={goalForm.target_value} onChange={e=>setGoalForm({...goalForm,target_value:e.target.value})}/></div><div className="field"><label>Início</label><input type="date" value={goalForm.period_start} onChange={e=>setGoalForm({...goalForm,period_start:e.target.value})}/></div><div className="field"><label>Fim</label><input type="date" value={goalForm.period_end} onChange={e=>setGoalForm({...goalForm,period_end:e.target.value})}/></div></div>
    </Modal>
  </div>
}

