import { useEffect, useMemo, useState } from 'react'
import { Archive, ArchiveRestore, CheckCircle2, FilePlus2, Pencil, Printer, Search, Trash2, Undo2, XCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Badge, EmptyState, ErrorBanner, LoadingBlock, Modal, PageHeader } from '../components/Ui'
import { dateTime, messageFromError, money } from '../services/data'

type Sale={id:string;patient_id:string;status:string;total_amount:number;paid_amount:number;entry_amount:number;installments_count:number;payment_due_days:number;payment_method_plan:string|null;notes:string|null;created_at:string;special_discount_amount:number;referral_discount_amount:number;late_fee_percent:number;monthly_interest_percent:number;grace_days:number;archived_at?:string|null;archive_reason?:string|null}
type Patient={id:string;full_name:string}
function escapeHtml(value:unknown){return String(value??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]||c))}
function monthStart(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`}
function monthEnd(){const d=new Date();return new Date(d.getFullYear(),d.getMonth()+1,0).toISOString().slice(0,10)}

export default function Sales(){
  const navigate=useNavigate();const [sales,setSales]=useState<Sale[]>([]);const [patients,setPatients]=useState<Patient[]>([]);const [installments,setInstallments]=useState<any[]>([])
  const [search,setSearch]=useState('');const [loading,setLoading]=useState(true);const [error,setError]=useState<string|null>(null);const [notice,setNotice]=useState<string|null>(null)
  const [editing,setEditing]=useState<Sale|null>(null);const [editForm,setEditForm]=useState({payment_method_plan:'',installments_count:'1',payment_due_days:'30',notes:''})
  const [periodStart,setPeriodStart]=useState(monthStart());const [periodEnd,setPeriodEnd]=useState(monthEnd());const [statusFilter,setStatusFilter]=useState('todos');const [showArchived,setShowArchived]=useState(false)
  async function load(){
    setLoading(true);setError(null)
    const [s,p,i]=await Promise.all([
      supabase.from('sales').select('id,patient_id,status,total_amount,paid_amount,entry_amount,installments_count,payment_due_days,payment_method_plan,notes,created_at,special_discount_amount,referral_discount_amount,late_fee_percent,monthly_interest_percent,grace_days,archived_at,archive_reason').order('created_at',{ascending:false}).limit(500),
      supabase.from('patients').select('id,full_name').order('full_name').limit(1000),
      supabase.from('installments').select('id,sale_id,amount,paid_amount,due_date').limit(4000),
    ])
    if(s.error)setError(messageFromError(s.error));else setSales((s.data??[]) as Sale[]);if(!p.error)setPatients((p.data??[]) as Patient[]);if(!i.error)setInstallments(i.data??[]);setLoading(false)
  }
  useEffect(()=>{void load()},[])
  const patientMap=useMemo(()=>Object.fromEntries(patients.map(p=>[p.id,p.full_name])),[patients])
  const pendingMap=useMemo(()=>{const m:Record<string,{count:number;amount:number}>={};installments.forEach(i=>{const b=Math.max(0,Number(i.amount||0)-Number(i.paid_amount||0));if(b<=.005)return;if(!m[i.sale_id])m[i.sale_id]={count:0,amount:0};m[i.sale_id].count++;m[i.sale_id].amount+=b});return m},[installments])
  const filtered=sales.filter(s=>{const d=(s.created_at||'').slice(0,10);const matchesSearch=!search.trim()||(patientMap[s.patient_id]||'').toLowerCase().includes(search.toLowerCase());const matchesPeriod=(!periodStart||d>=periodStart)&&(!periodEnd||d<=periodEnd);const matchesStatus=statusFilter==='todos'||s.status===statusFilter;const matchesArchive=showArchived?Boolean(s.archived_at):!s.archived_at;return matchesSearch&&matchesPeriod&&matchesStatus&&matchesArchive})
  const periodSales=filtered.reduce((sum,s)=>sum+Number(s.total_amount||0),0)
  const periodPaid=filtered.reduce((sum,s)=>sum+Number(s.paid_amount||0),0)
  function openEdit(s:Sale){setEditing(s);setEditForm({payment_method_plan:s.payment_method_plan||'',installments_count:String(s.installments_count||1),payment_due_days:String(s.payment_due_days||0),notes:s.notes||''})}
  async function saveEdit(){if(!editing)return;const {error:e}=await supabase.from('sales').update({payment_method_plan:editForm.payment_method_plan||null,payment_notes:editForm.payment_method_plan||null,installments_count:Math.max(1,Number(editForm.installments_count||1)),payment_due_days:Math.max(0,Number(editForm.payment_due_days||0)),notes:editForm.notes.trim()||null}).eq('id',editing.id);if(e)return setError(messageFromError(e));setEditing(null);setNotice('Orçamento/venda atualizado.');await load()}
  async function approveSale(s:Sale){
    if(s.status!=='orcamento'||!window.confirm(`Aprovar o orçamento de ${patientMap[s.patient_id]||'Paciente'} como venda?`))return
    setError(null);setNotice(null)
    const {count,error:ce}=await supabase.from('installments').select('id',{count:'exact',head:true}).eq('sale_id',s.id);if(ce)return setError(messageFromError(ce))
    if((count??0)===0){
      const totalRemaining=Math.max(0,Number(s.total_amount||0)-Number(s.paid_amount||0));const rows:any[]=[];let remaining=totalRemaining;let number=1
      const plannedEntry=Math.min(Math.max(0,Number(s.entry_amount||0)),remaining)
      if(plannedEntry>0){rows.push({sale_id:s.id,installment_number:number,amount:plannedEntry,due_date:new Date().toISOString().slice(0,10),late_fee_percent:s.late_fee_percent||0,monthly_interest_percent:s.monthly_interest_percent||0,grace_days:s.grace_days||0});number++;remaining=Math.max(0,remaining-plannedEntry)}
      const qty=Math.max(1,Number(s.installments_count||1))
      if(remaining>0){const base=Math.floor((remaining/qty)*100)/100;for(let idx=0;idx<qty;idx++){const due=new Date();due.setDate(due.getDate()+Math.max(0,Number(s.payment_due_days||0)));due.setMonth(due.getMonth()+idx);const amount=idx===qty-1?Math.round((remaining-base*(qty-1))*100)/100:base;rows.push({sale_id:s.id,installment_number:number+idx,amount,due_date:due.toISOString().slice(0,10),late_fee_percent:s.late_fee_percent||0,monthly_interest_percent:s.monthly_interest_percent||0,grace_days:s.grace_days||0})}}
      if(rows.length){const {error:ie}=await supabase.from('installments').insert(rows);if(ie)return setError(messageFromError(ie))}
    }
    const next=Number(s.paid_amount||0)>=Number(s.total_amount||0)?'pago':'aguardando_pagamento'
    const {error:ue}=await supabase.from('sales').update({status:next}).eq('id',s.id);if(ue)return setError(messageFromError(ue));setNotice('Venda aprovada. As parcelas aparecem no Financeiro.');await load()
  }
  async function cancelSale(s:Sale){
    setError(null);setNotice(null)
    const hasPayment=Number(s.paid_amount||0)>0
    const message=hasPayment
      ? `Esta venda possui ${money(s.paid_amount)} recebido. Cancelar e estornar os recibos/pagamentos vinculados?`
      : 'Cancelar esta venda/orçamento mantendo o histórico?'
    if(!window.confirm(message))return
    const reason=window.prompt(hasPayment?'Informe o motivo do cancelamento/estorno:':'Informe o motivo do cancelamento:')
    if(!reason?.trim())return setError('Informe o motivo para continuar.')
    if(hasPayment){
      const typed=window.prompt('Para confirmar o estorno financeiro, digite ESTORNAR:')
      if(typed!=='ESTORNAR')return
    }
    const {data,error:e}=await supabase.rpc('admin_cancel_sale_v28',{
      p_id:s.id,
      p_reason:reason.trim(),
      p_estorno:hasPayment,
    })
    if(e)return setError(messageFromError(e))
    if(!data?.ok)return setError('O banco não confirmou o cancelamento.')
    setNotice(hasPayment
      ? 'Venda cancelada e recebimentos estornados. O histórico foi preservado.'
      : 'Venda/orçamento cancelado com histórico preservado.')
    await load()
  }
  async function archiveSale(s:Sale){
    setError(null);setNotice(null)
    const archive=!s.archived_at
    const reason=archive?window.prompt('Informe o motivo para arquivar/desativar esta venda:'):''
    if(archive&&!reason?.trim())return setError('Informe o motivo para arquivar a venda.')
    const {data,error:e}=await supabase.rpc('admin_archive_sale_v29',{p_id:s.id,p_archive:archive,p_reason:archive?reason?.trim()||null:null})
    if(e)return setError(messageFromError(e));if(!data?.ok)return setError('O banco não confirmou a alteração.')
    setNotice(archive?'Venda arquivada/desativada. O histórico foi preservado.':'Venda reativada.')
    await load()
  }
  async function deleteSale(s:Sale){
    setError(null);setNotice(null)
    if(Number(s.paid_amount||0)>0)return setError('Esta venda tem pagamento. Primeiro clique em Estornar. Depois que o financeiro voltar a zero, use Excluir.')
    const broken=Number(s.total_amount||0)<=0
    const allowed=s.status==='orcamento'||s.status==='cancelado'||broken
    if(!allowed)return setError('Venda válida já convertida não pode ser excluída. Cancele a venda para preservar o histórico.')
    const label=broken?'registro incompleto/zerado':s.status==='orcamento'?'orçamento':'registro cancelado'
    if(!window.confirm(`Excluir definitivamente este ${label}?`))return
    const {data,error:e}=await supabase.rpc('admin_delete_sale_safe_v25_1',{p_id:s.id})
    if(e)return setError(messageFromError(e))
    if(!data?.ok)return setError('O banco não confirmou a exclusão.')
    setNotice(broken?'Registro incompleto removido com segurança.':'Registro excluído definitivamente.')
    await load()
  }
  async function printQuote(s:Sale){
    const {data:items,error:e}=await supabase.from('sale_items').select('item_name,quantity,unit_price,discount_amount,total_amount').eq('sale_id',s.id).order('created_at');if(e)return setError(messageFromError(e))
    const popup=window.open('','_blank','width=900,height=700');if(!popup)return setError('O navegador bloqueou a janela de impressão.')
    const rows=(items??[]).map((i:any)=>`<tr><td>${escapeHtml(i.item_name||'Serviço')}</td><td>${escapeHtml(i.quantity)}</td><td>${escapeHtml(money(i.unit_price))}</td><td>${escapeHtml(money(i.discount_amount))}</td><td>${escapeHtml(money(i.total_amount))}</td></tr>`).join('')
    popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Orçamento</title><style>body{font-family:Arial;padding:40px;color:#222}h1{color:#8c1830}table{width:100%;border-collapse:collapse;margin-top:24px}th,td{border-bottom:1px solid #ddd;padding:10px;text-align:left}.total{font-size:22px;margin-top:24px;font-weight:700}</style></head><body><h1>Orçamento — Clínica Dra. Andressa</h1><p><strong>Paciente:</strong> ${escapeHtml(patientMap[s.patient_id]||'Paciente')}</p><p><strong>Data:</strong> ${escapeHtml(dateTime(s.created_at))}</p><table><thead><tr><th>Serviço</th><th>Qtd.</th><th>Unitário</th><th>Desconto</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table><p>Desconto especial: ${escapeHtml(money(s.special_discount_amount||0))}</p><p>Desconto por indicação: ${escapeHtml(money(s.referral_discount_amount||0))}</p><div class="total">Total: ${escapeHtml(money(s.total_amount))}</div><p>Documento comercial sem valor fiscal.</p><script>window.onload=()=>window.print()</script></body></html>`);popup.document.close()
  }

  return <div>
    <PageHeader eyebrow="COMERCIAL" title="Vendas / Orçamentos" description="Orçamento não entra no faturamento. Aprove a negociação quando o cliente fechar." actions={<button className="btn primary" onClick={()=>navigate('/atendimento/nova')}><FilePlus2 size={15}/>Novo orçamento</button>}/>
    <ErrorBanner text={error}/>{notice&&<div className="success-banner">{notice}</div>}
    <div style={{display:'flex',gap:12,alignItems:'end',flexWrap:'wrap',margin:'0 0 16px'}}>
      <div className="search-box" style={{minWidth:300}}><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar paciente..."/></div>
      <div className="field"><label>De</label><input type="date" value={periodStart} onChange={e=>setPeriodStart(e.target.value)}/></div>
      <div className="field"><label>Até</label><input type="date" value={periodEnd} onChange={e=>setPeriodEnd(e.target.value)}/></div>
      <div className="field"><label>Status</label><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option value="todos">Todos</option><option value="orcamento">Orçamentos</option><option value="aguardando_pagamento">Aguardando pagamento</option><option value="pago">Pago</option><option value="cancelado">Cancelado</option></select></div>
      <button className="btn secondary" onClick={()=>setShowArchived(v=>!v)}>{showArchived?<ArchiveRestore size={14}/>:<Archive size={14}/>} {showArchived?'Ver ativos':'Ver arquivados'}</button>
    </div>
    <div className="metric-row" style={{marginBottom:16}}><div className="mini-metric"><span>Registros no período</span><strong>{filtered.length}</strong></div><div className="mini-metric"><span>Total vendido</span><strong>{money(periodSales)}</strong></div><div className="mini-metric"><span>Total recebido</span><strong>{money(periodPaid)}</strong></div></div>
    <div className="data-card">{loading?<LoadingBlock/>:filtered.length===0?<EmptyState text="Nenhuma venda ou orçamento encontrado."/>:<div className="table-wrap"><table className="data-table">
      <thead><tr><th>Paciente</th><th>Data</th><th>Forma prevista</th><th>Total</th><th>Pago</th><th>Pendências</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>{filtered.map(s=>{const p=s.status==='orcamento'||s.status==='cancelado'?undefined:pendingMap[s.id];return <tr key={s.id}>
        <td>{patientMap[s.patient_id]||'Paciente'}</td><td>{dateTime(s.created_at)}</td><td>{s.payment_method_plan||'—'}</td><td>{money(s.total_amount)}</td><td>{money(s.paid_amount)}</td>
        <td>{p?<strong>{p.count} · {money(p.amount)}</strong>:'—'}</td><td><Badge value={s.status}/></td>
        <td><div className="action-row"><button className="btn small secondary" onClick={()=>openEdit(s)}><Pencil size={13}/>Editar</button><button className="btn small secondary" onClick={()=>void printQuote(s)}><Printer size={13}/>Orçamento</button>{s.status==='orcamento'&&<button className="btn small primary" onClick={()=>void approveSale(s)}><CheckCircle2 size={13}/>Aprovar venda</button>}{s.status!=='cancelado'&&Number(s.paid_amount||0)>0&&<button className="btn small danger" onClick={()=>void cancelSale(s)}><Undo2 size={13}/>Estornar</button>}{s.status!=='cancelado'&&Number(s.paid_amount||0)<=0&&<button className="btn small secondary" onClick={()=>void cancelSale(s)}><XCircle size={13}/>Cancelar</button>}<button className="btn small secondary" onClick={()=>void archiveSale(s)}>{s.archived_at?<ArchiveRestore size={13}/>:<Archive size={13}/>} {s.archived_at?'Reativar':'Arquivar'}</button><button className="btn small danger" title={Number(s.paid_amount||0)>0?'Estorne antes de excluir':'Excluir venda/orçamento'} onClick={()=>void deleteSale(s)}><Trash2 size={13}/>Excluir</button></div></td>
      </tr>})}</tbody>
    </table></div>}</div>
    <Modal open={Boolean(editing)} title="Editar condições" onClose={()=>setEditing(null)} footer={<><button className="btn secondary" onClick={()=>setEditing(null)}>Cancelar</button><button className="btn primary" onClick={()=>void saveEdit()}>Salvar alterações</button></>}>
      <div className="form-grid"><div className="field full"><label>Forma prevista</label><input value={editForm.payment_method_plan} onChange={e=>setEditForm({...editForm,payment_method_plan:e.target.value})}/></div><div className="field"><label>Parcelas</label><input type="number" min="1" value={editForm.installments_count} onChange={e=>setEditForm({...editForm,installments_count:e.target.value})}/></div><div className="field"><label>Primeiro vencimento em dias</label><input type="number" min="0" value={editForm.payment_due_days} onChange={e=>setEditForm({...editForm,payment_due_days:e.target.value})}/></div><div className="field full"><label>Observações</label><textarea value={editForm.notes} onChange={e=>setEditForm({...editForm,notes:e.target.value})}/></div></div>
    </Modal>
  </div>
}

