-- ============================================================
-- BLOCO 28 - ESTORNOS, CANCELAMENTOS E EXCLUSOES SEGURAS
-- Clinica Dra. Andressa
-- ============================================================

create extension if not exists pgcrypto;

-- Mantem compatibilidade com os status usados pelo financeiro atual.
alter type public.installment_status add value if not exists 'pago';
alter type public.financial_status add value if not exists 'em_dia';
alter type public.financial_status add value if not exists 'pendente';
alter type public.financial_status add value if not exists 'inadimplente';

-- ----------------------------------------------------------------
-- 1. AUDITORIA
-- ----------------------------------------------------------------
create table if not exists public.admin_financial_audit (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid null default auth.uid(),
  action text not null,
  entity_type text not null,
  entity_id uuid null,
  reason text null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.admin_financial_audit enable row level security;

drop policy if exists bloco28_audit_view on public.admin_financial_audit;
create policy bloco28_audit_view
on public.admin_financial_audit
for select
to authenticated
using (
  public.staff_can('finance','view')
  or public.staff_can('sales','view')
  or public.staff_can('contracts','view')
);

-- ----------------------------------------------------------------
-- 2. COLUNAS DE CANCELAMENTO / ESTORNO
-- ----------------------------------------------------------------
alter table if exists public.payment_receipts
  add column if not exists voided_at timestamptz null,
  add column if not exists voided_by uuid null,
  add column if not exists void_reason text null;

alter table if exists public.expenses
  add column if not exists voided_at timestamptz null,
  add column if not exists voided_by uuid null,
  add column if not exists void_reason text null;

alter table if exists public.contracts
  add column if not exists cancelled_at timestamptz null,
  add column if not exists cancelled_by uuid null,
  add column if not exists cancel_reason text null;

alter table if exists public.sales
  add column if not exists cancelled_at timestamptz null,
  add column if not exists cancelled_by uuid null,
  add column if not exists cancel_reason text null;

create index if not exists idx_payment_receipts_voided_at
  on public.payment_receipts(voided_at);

create index if not exists idx_expenses_voided_at
  on public.expenses(voided_at);

-- ----------------------------------------------------------------
-- 3. HELPERS SEGUROS PARA ENUMS / STATUS
-- ----------------------------------------------------------------
create or replace function public.bloco28_set_installment_status(
  p_installment_id uuid,
  p_paid numeric,
  p_amount numeric
)
returns void
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_data_type text;
  v_schema text;
  v_type text;
  v_label text;
begin
  select data_type,udt_schema,udt_name
    into v_data_type,v_schema,v_type
  from information_schema.columns
  where table_schema='public'
    and table_name='installments'
    and column_name='status';

  if coalesce(p_paid,0) >= coalesce(p_amount,0)-0.005 then
    v_label:='pago';
  elsif coalesce(p_paid,0)>0 then
    v_label:='parcial';
  else
    v_label:='pendente';
  end if;

  if v_data_type='USER-DEFINED' then
    if not exists(
      select 1
      from pg_type t
      join pg_namespace n on n.oid=t.typnamespace
      join pg_enum e on e.enumtypid=t.oid
      where n.nspname=v_schema
        and t.typname=v_type
        and e.enumlabel=v_label
    ) then
      if exists(
        select 1
        from pg_type t
        join pg_namespace n on n.oid=t.typnamespace
        join pg_enum e on e.enumtypid=t.oid
        where n.nspname=v_schema
          and t.typname=v_type
          and e.enumlabel='pendente'
      ) then
        v_label:='pendente';
      else
        return;
      end if;
    end if;

    execute format(
      'update public.installments set status=%L::%I.%I where id=$1',
      v_label,v_schema,v_type
    ) using p_installment_id;
  else
    update public.installments set status=v_label where id=p_installment_id;
  end if;
end $$;

create or replace function public.bloco28_refresh_patient_financial_status(
  p_patient_id uuid
)
returns void
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_target text;
  v_data_type text;
  v_schema text;
  v_type text;
begin
  if p_patient_id is null then return; end if;

  if exists(
    select 1
    from public.installments i
    join public.sales s on s.id=i.sale_id
    where s.patient_id=p_patient_id
      and s.status::text not in ('orcamento','cancelado')
      and coalesce(i.paid_amount,0)<coalesce(i.amount,0)
      and current_date>i.due_date+coalesce(i.grace_days,0)
  ) then
    v_target:='inadimplente';
  elsif exists(
    select 1
    from public.installments i
    join public.sales s on s.id=i.sale_id
    where s.patient_id=p_patient_id
      and s.status::text not in ('orcamento','cancelado')
      and coalesce(i.paid_amount,0)<coalesce(i.amount,0)
  ) then
    v_target:='pendente';
  else
    v_target:='em_dia';
  end if;

  select data_type,udt_schema,udt_name
    into v_data_type,v_schema,v_type
  from information_schema.columns
  where table_schema='public'
    and table_name='patients'
    and column_name='financial_status';

  if v_data_type='USER-DEFINED' then
    if exists(
      select 1
      from pg_type t
      join pg_namespace n on n.oid=t.typnamespace
      join pg_enum e on e.enumtypid=t.oid
      where n.nspname=v_schema
        and t.typname=v_type
        and e.enumlabel=v_target
    ) then
      execute format(
        'update public.patients set financial_status=%L::%I.%I where id=$1',
        v_target,v_schema,v_type
      ) using p_patient_id;
    end if;
  else
    update public.patients
    set financial_status=v_target
    where id=p_patient_id;
  end if;
end $$;

-- ----------------------------------------------------------------
-- 4. CANCELAR RECIBO + ESTORNAR PAGAMENTO
-- ----------------------------------------------------------------
create or replace function public.admin_void_receipt_v28(
  p_receipt_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  r public.payment_receipts%rowtype;
  i public.installments%rowtype;
  s public.sales%rowtype;
  v_new_paid numeric(14,2);
  v_sale_paid numeric(14,2);
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('finance','delete') then
    raise exception 'Sem permissao para cancelar recibos ou estornar pagamentos.';
  end if;
  if nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'Informe o motivo do estorno.';
  end if;

  select * into r
  from public.payment_receipts
  where id=p_receipt_id
  for update;

  if not found then
    return jsonb_build_object('ok',true,'already_missing',true);
  end if;

  if r.voided_at is not null then
    return jsonb_build_object('ok',true,'already_voided',true,'receipt_number',r.receipt_number);
  end if;

  select * into i
  from public.installments
  where id=r.installment_id
  for update;

  if not found then
    raise exception 'Parcela vinculada ao recibo nao foi encontrada.';
  end if;

  select * into s
  from public.sales
  where id=r.sale_id
  for update;

  if not found then
    raise exception 'Venda vinculada ao recibo nao foi encontrada.';
  end if;

  update public.installments
  set paid_amount=greatest(0,coalesce(paid_amount,0)-coalesce(r.principal_paid,0)),
      late_fee_paid=greatest(0,coalesce(late_fee_paid,0)-coalesce(r.late_fee_paid,0)),
      interest_paid=greatest(0,coalesce(interest_paid,0)-coalesce(r.interest_paid,0))
  where id=i.id
  returning paid_amount into v_new_paid;

  perform public.bloco28_set_installment_status(
    i.id,
    v_new_paid,
    i.amount
  );

  update public.payment_receipts
  set voided_at=now(),
      voided_by=auth.uid(),
      void_reason=trim(p_reason)
  where id=r.id;

  select coalesce(sum(coalesce(paid_amount,0)),0)
    into v_sale_paid
  from public.installments
  where sale_id=s.id;

  update public.sales
  set paid_amount=least(coalesce(total_amount,0),v_sale_paid),
      status=case
        when status::text='cancelado' then status
        when v_sale_paid>=coalesce(total_amount,0)-0.005 then 'pago'
        when status::text='orcamento' then status
        else 'aguardando_pagamento'
      end
  where id=s.id;

  perform public.bloco28_refresh_patient_financial_status(s.patient_id);

  insert into public.admin_financial_audit(
    action,entity_type,entity_id,reason,details
  ) values(
    'receipt_voided_payment_reversed',
    'payment_receipt',
    r.id,
    trim(p_reason),
    jsonb_build_object(
      'receipt_number',r.receipt_number,
      'sale_id',r.sale_id,
      'installment_id',r.installment_id,
      'amount_received',r.amount_received,
      'principal_reversed',r.principal_paid,
      'late_fee_reversed',r.late_fee_paid,
      'interest_reversed',r.interest_paid
    )
  );

  return jsonb_build_object(
    'ok',true,
    'receipt_id',r.id,
    'receipt_number',r.receipt_number,
    'sale_id',r.sale_id,
    'installment_id',r.installment_id,
    'amount_reversed',r.amount_received
  );
end $$;

revoke all on function public.admin_void_receipt_v28(uuid,text) from public;
grant execute on function public.admin_void_receipt_v28(uuid,text) to authenticated;

-- ----------------------------------------------------------------
-- 5. DESPESAS: EXCLUIR SE NAO PAGA / ESTORNAR SE PAGA
-- ----------------------------------------------------------------
create or replace function public.admin_delete_or_void_expense_v28(
  p_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  e public.expenses%rowtype;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('finance','delete') then
    raise exception 'Sem permissao para excluir ou estornar despesas.';
  end if;
  if nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'Informe o motivo da operacao.';
  end if;

  select * into e
  from public.expenses
  where id=p_id
  for update;

  if not found then
    return jsonb_build_object('ok',true,'already_missing',true);
  end if;

  if e.voided_at is not null then
    return jsonb_build_object('ok',true,'already_voided',true);
  end if;

  if coalesce(e.paid_amount,0)>0 then
    update public.expenses
    set voided_at=now(),
        voided_by=auth.uid(),
        void_reason=trim(p_reason),
        paid_amount=0
    where id=e.id;

    insert into public.admin_financial_audit(
      action,entity_type,entity_id,reason,details
    ) values(
      'expense_voided',
      'expense',
      e.id,
      trim(p_reason),
      jsonb_build_object(
        'description',e.description,
        'total_amount',e.total_amount,
        'paid_amount_before',e.paid_amount
      )
    );

    return jsonb_build_object('ok',true,'voided',true,'paid_amount_reversed',e.paid_amount);
  end if;

  delete from public.expenses where id=e.id;

  insert into public.admin_financial_audit(
    action,entity_type,entity_id,reason,details
  ) values(
    'expense_deleted',
    'expense',
    e.id,
    trim(p_reason),
    jsonb_build_object('description',e.description,'total_amount',e.total_amount)
  );

  return jsonb_build_object('ok',true,'deleted',true);
end $$;

revoke all on function public.admin_delete_or_void_expense_v28(uuid,text) from public;
grant execute on function public.admin_delete_or_void_expense_v28(uuid,text) to authenticated;

-- ----------------------------------------------------------------
-- 6. CONTRATOS: CANCELAMENTO SEGURO, INCLUSIVE ASSINADOS
-- ----------------------------------------------------------------
create or replace function public.admin_cancel_contract_v28(
  p_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  c public.contracts%rowtype;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not (public.bloco21_is_admin() or public.staff_can('contracts','delete')) then
    raise exception 'Sem permissao para cancelar contratos.';
  end if;
  if nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'Informe o motivo do cancelamento.';
  end if;

  select * into c
  from public.contracts
  where id=p_id
  for update;

  if not found then
    return jsonb_build_object('ok',true,'already_missing',true);
  end if;

  if c.status::text='cancelado' then
    return jsonb_build_object('ok',true,'already_cancelled',true,'signed',c.signed_at is not null);
  end if;

  update public.contracts
  set status='cancelado',
      cancelled_at=now(),
      cancelled_by=auth.uid(),
      cancel_reason=trim(p_reason)
  where id=c.id;

  insert into public.admin_financial_audit(
    action,entity_type,entity_id,reason,details
  ) values(
    'contract_cancelled',
    'contract',
    c.id,
    trim(p_reason),
    jsonb_build_object(
      'contract_number',c.contract_number,
      'sale_id',c.sale_id,
      'patient_id',c.patient_id,
      'signed_at',c.signed_at,
      'status_before',c.status::text
    )
  );

  return jsonb_build_object(
    'ok',true,
    'cancelled',true,
    'signed',c.signed_at is not null,
    'contract_number',c.contract_number
  );
end $$;

revoke all on function public.admin_cancel_contract_v28(uuid,text) from public;
grant execute on function public.admin_cancel_contract_v28(uuid,text) to authenticated;

-- ----------------------------------------------------------------
-- 7. VENDAS / ORCAMENTOS: CANCELAR E, SE HOUVER BAIXA, ESTORNAR
-- ----------------------------------------------------------------
create or replace function public.admin_cancel_sale_v28(
  p_id uuid,
  p_reason text,
  p_estorno boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  s public.sales%rowtype;
  r record;
  v_receipts integer:=0;
  v_voided integer:=0;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('sales','delete') then
    raise exception 'Sem permissao para cancelar vendas/orcamentos.';
  end if;
  if nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'Informe o motivo do cancelamento.';
  end if;

  select * into s
  from public.sales
  where id=p_id
  for update;

  if not found then
    return jsonb_build_object('ok',true,'already_missing',true);
  end if;

  if s.status::text='cancelado' then
    return jsonb_build_object('ok',true,'already_cancelled',true);
  end if;

  select count(*) into v_receipts
  from public.payment_receipts
  where sale_id=s.id
    and voided_at is null;

  if (coalesce(s.paid_amount,0)>0 or v_receipts>0) and not p_estorno then
    raise exception 'A venda possui recebimentos. Confirme o estorno financeiro para cancelar.';
  end if;

  if p_estorno and v_receipts>0 then
    if not public.staff_can('finance','delete') then
      raise exception 'O estorno exige permissao de exclusao/estorno no Financeiro.';
    end if;

    for r in
      select id
      from public.payment_receipts
      where sale_id=s.id
        and voided_at is null
      order by created_at desc
    loop
      perform public.admin_void_receipt_v28(r.id,trim(p_reason));
      v_voided:=v_voided+1;
    end loop;
  end if;

  update public.sales
  set status='cancelado',
      cancelled_at=now(),
      cancelled_by=auth.uid(),
      cancel_reason=trim(p_reason)
  where id=s.id;

  -- Contratos NAO assinados podem ser cancelados junto com a venda.
  update public.contracts
  set status='cancelado',
      cancelled_at=coalesce(cancelled_at,now()),
      cancelled_by=coalesce(cancelled_by,auth.uid()),
      cancel_reason=coalesce(cancel_reason,'Venda cancelada: '||trim(p_reason))
  where sale_id=s.id
    and signed_at is null
    and status::text<>'cancelado';

  perform public.bloco28_refresh_patient_financial_status(s.patient_id);

  insert into public.admin_financial_audit(
    action,entity_type,entity_id,reason,details
  ) values(
    case when p_estorno then 'sale_cancelled_with_reversal' else 'sale_cancelled' end,
    'sale',
    s.id,
    trim(p_reason),
    jsonb_build_object(
      'patient_id',s.patient_id,
      'status_before',s.status::text,
      'total_amount',s.total_amount,
      'paid_amount_before',s.paid_amount,
      'receipts_voided',v_voided
    )
  );

  return jsonb_build_object(
    'ok',true,
    'cancelled',true,
    'receipts_voided',v_voided,
    'paid_amount_before',s.paid_amount
  );
end $$;

revoke all on function public.admin_cancel_sale_v28(uuid,text,boolean) from public;
grant execute on function public.admin_cancel_sale_v28(uuid,text,boolean) to authenticated;


-- ----------------------------------------------------------------
-- 8. VALIDACAO PUBLICA DO RECIBO TAMBEM MOSTRA ESTORNOS
-- ----------------------------------------------------------------
create or replace function public.verify_payment_receipt_v27(p_code text)
returns jsonb
language plpgsql
security definer
stable
set search_path=public,pg_temp
as $$
declare
  r record;
  p record;
begin
  select * into r
  from public.payment_receipts
  where upper(verification_code)=upper(trim(coalesce(p_code,'')))
  limit 1;

  if not found then
    return jsonb_build_object('valid',false);
  end if;

  select full_name into p
  from public.patients
  where id=r.patient_id;

  return jsonb_build_object(
    'valid',true,
    'voided',r.voided_at is not null,
    'voided_at',r.voided_at,
    'void_reason',r.void_reason,
    'receipt_number',r.receipt_number,
    'patient_name',p.full_name,
    'amount_received',r.amount_received,
    'principal_paid',r.principal_paid,
    'late_fee_paid',r.late_fee_paid,
    'interest_paid',r.interest_paid,
    'method',r.method,
    'paid_at',r.created_at,
    'overdue_days',r.overdue_days
  );
end $$;

revoke all on function public.verify_payment_receipt_v27(text) from public;
grant execute on function public.verify_payment_receipt_v27(text) to anon,authenticated;

notify pgrst, 'reload schema';
