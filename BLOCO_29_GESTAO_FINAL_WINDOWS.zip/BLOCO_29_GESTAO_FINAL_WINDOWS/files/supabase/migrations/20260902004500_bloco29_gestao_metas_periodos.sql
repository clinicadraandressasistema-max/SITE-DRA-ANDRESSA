begin;

-- ============================================================
-- BLOCO 29 - GESTAO: ARQUIVAMENTO, ESTORNOS, METRICAS E METAS
-- ============================================================

-- 1) Arquivamento/desativacao de vendas sem destruir historico
alter table if exists public.sales
  add column if not exists archived_at timestamptz null,
  add column if not exists archived_by uuid null,
  add column if not exists archive_reason text null;

create index if not exists idx_sales_archived_at on public.sales(archived_at);

create or replace function public.admin_archive_sale_v29(
  p_id uuid,
  p_archive boolean,
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  s public.sales%rowtype;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('sales','edit') and not public.staff_can('sales','delete') then
    raise exception 'Sem permissao para arquivar/desarquivar vendas.';
  end if;
  if coalesce(p_archive,false) and nullif(trim(coalesce(p_reason,'')),'') is null then
    raise exception 'Informe o motivo do arquivamento.';
  end if;

  select * into s from public.sales where id=p_id for update;
  if not found then return jsonb_build_object('ok',true,'already_missing',true); end if;

  update public.sales
  set archived_at=case when p_archive then now() else null end,
      archived_by=case when p_archive then auth.uid() else null end,
      archive_reason=case when p_archive then trim(p_reason) else null end
  where id=p_id;

  insert into public.admin_financial_audit(action,entity_type,entity_id,reason,details,actor_user_id)
  values(
    case when p_archive then 'sale_archived' else 'sale_reactivated' end,
    'sale',p_id,case when p_archive then trim(p_reason) else 'Reativada' end,
    jsonb_build_object('status',s.status::text,'total_amount',s.total_amount,'paid_amount',s.paid_amount),
    auth.uid()
  );

  return jsonb_build_object('ok',true,'archived',p_archive);
end $$;

revoke all on function public.admin_archive_sale_v29(uuid,boolean,text) from public;
grant execute on function public.admin_archive_sale_v29(uuid,boolean,text) to authenticated;

-- 2) Exclusao definitiva APENAS depois de um recibo ja ter sido estornado.
-- O registro de auditoria continua preservado.
create or replace function public.admin_delete_voided_receipt_v29(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  r public.payment_receipts%rowtype;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('finance','delete') then raise exception 'Sem permissao para excluir recibos.'; end if;

  select * into r from public.payment_receipts where id=p_id for update;
  if not found then return jsonb_build_object('ok',true,'already_missing',true); end if;
  if r.voided_at is null then raise exception 'Primeiro cancele/estorne o recibo. Depois sera permitido excluir.'; end if;

  insert into public.admin_financial_audit(action,entity_type,entity_id,reason,details,actor_user_id)
  values('voided_receipt_deleted','payment_receipt',r.id,coalesce(r.void_reason,'Recibo estornado excluido'),jsonb_build_object('receipt_number',r.receipt_number,'sale_id',r.sale_id,'amount_received',r.amount_received,'voided_at',r.voided_at),auth.uid());

  delete from public.payment_receipts where id=p_id;
  return jsonb_build_object('ok',true,'deleted',true);
end $$;

revoke all on function public.admin_delete_voided_receipt_v29(uuid) from public;
grant execute on function public.admin_delete_voided_receipt_v29(uuid) to authenticated;

create or replace function public.admin_delete_voided_expense_v29(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  e public.expenses%rowtype;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not public.staff_can('finance','delete') then raise exception 'Sem permissao para excluir despesas.'; end if;

  select * into e from public.expenses where id=p_id for update;
  if not found then return jsonb_build_object('ok',true,'already_missing',true); end if;
  if e.voided_at is null then raise exception 'Despesa ainda nao esta estornada. Use Estornar primeiro.'; end if;

  insert into public.admin_financial_audit(action,entity_type,entity_id,reason,details,actor_user_id)
  values('voided_expense_deleted','expense',e.id,coalesce(e.void_reason,'Despesa estornada excluida'),jsonb_build_object('description',e.description,'total_amount',e.total_amount,'paid_amount',e.paid_amount,'voided_at',e.voided_at),auth.uid());

  delete from public.expenses where id=p_id;
  return jsonb_build_object('ok',true,'deleted',true);
end $$;

revoke all on function public.admin_delete_voided_expense_v29(uuid) from public;
grant execute on function public.admin_delete_voided_expense_v29(uuid) to authenticated;

-- 3) Metas gerenciais
create table if not exists public.management_goals (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  metric_key text not null check (metric_key in ('sales_total','sales_count','received_total','appointments_count','expenses_total')),
  target_value numeric(14,2) not null check (target_value > 0),
  period_start date not null,
  period_end date not null,
  active boolean not null default true,
  created_by uuid null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint management_goals_period_check check (period_end >= period_start)
);

alter table public.management_goals enable row level security;

drop policy if exists management_goals_view_v29 on public.management_goals;
create policy management_goals_view_v29 on public.management_goals
for select to authenticated
using (
  public.bloco21_is_admin()
  or public.staff_can('finance','view')
  or public.staff_can('sales','view')
);

drop policy if exists management_goals_manage_v29 on public.management_goals;
create policy management_goals_manage_v29 on public.management_goals
for all to authenticated
using (
  public.bloco21_is_admin()
  or public.staff_can('finance','edit')
  or public.staff_can('sales','edit')
)
with check (
  public.bloco21_is_admin()
  or public.staff_can('finance','edit')
  or public.staff_can('sales','edit')
);

create or replace function public.admin_save_goal_v29(
  p_id uuid,
  p_title text,
  p_metric_key text,
  p_target_value numeric,
  p_period_start date,
  p_period_end date
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not (public.bloco21_is_admin() or public.staff_can('finance','edit') or public.staff_can('sales','edit')) then
    raise exception 'Sem permissao para cadastrar metas.';
  end if;
  if nullif(trim(coalesce(p_title,'')),'') is null then raise exception 'Informe o nome da meta.'; end if;
  if p_metric_key not in ('sales_total','sales_count','received_total','appointments_count','expenses_total') then raise exception 'Indicador de meta invalido.'; end if;
  if coalesce(p_target_value,0)<=0 then raise exception 'Meta deve ser maior que zero.'; end if;
  if p_period_start is null or p_period_end is null or p_period_end<p_period_start then raise exception 'Periodo da meta invalido.'; end if;

  if p_id is null then
    insert into public.management_goals(title,metric_key,target_value,period_start,period_end,created_by)
    values(trim(p_title),p_metric_key,p_target_value,p_period_start,p_period_end,auth.uid())
    returning id into v_id;
  else
    update public.management_goals
    set title=trim(p_title),metric_key=p_metric_key,target_value=p_target_value,period_start=p_period_start,period_end=p_period_end,updated_at=now()
    where id=p_id
    returning id into v_id;
    if v_id is null then raise exception 'Meta nao encontrada.'; end if;
  end if;
  return jsonb_build_object('ok',true,'id',v_id);
end $$;

revoke all on function public.admin_save_goal_v29(uuid,text,text,numeric,date,date) from public;
grant execute on function public.admin_save_goal_v29(uuid,text,text,numeric,date,date) to authenticated;

create or replace function public.admin_delete_goal_v29(p_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not (public.bloco21_is_admin() or public.staff_can('finance','delete') or public.staff_can('sales','delete')) then raise exception 'Sem permissao para excluir metas.'; end if;
  delete from public.management_goals where id=p_id;
  return jsonb_build_object('ok',true,'deleted',found);
end $$;

revoke all on function public.admin_delete_goal_v29(uuid) from public;
grant execute on function public.admin_delete_goal_v29(uuid) to authenticated;

-- 4) Metricas por periodo. A contagem de atendimentos e resiliente a nomes diferentes de tabela/campo.
create or replace function public.admin_period_metrics_v29(p_start date,p_end date)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_sales_count bigint:=0;
  v_sales_total numeric:=0;
  v_received_total numeric:=0;
  v_expenses_total numeric:=0;
  v_cancelled_sales bigint:=0;
  v_reversals_count bigint:=0;
  v_appointments_count bigint:=0;
  v_table text;
  v_date_col text;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not (public.bloco21_is_admin() or public.staff_can('finance','view') or public.staff_can('sales','view')) then raise exception 'Sem permissao para visualizar metricas.'; end if;
  if p_start is null or p_end is null or p_end<p_start then raise exception 'Periodo invalido.'; end if;

  select count(*),coalesce(sum(total_amount),0)
    into v_sales_count,v_sales_total
  from public.sales
  where created_at>=p_start::timestamptz
    and created_at<(p_end+1)::timestamptz
    and status::text not in ('orcamento','cancelado');

  select count(*) into v_cancelled_sales
  from public.sales
  where created_at>=p_start::timestamptz
    and created_at<(p_end+1)::timestamptz
    and status::text='cancelado';

  select coalesce(sum(amount_received),0) into v_received_total
  from public.payment_receipts
  where created_at>=p_start::timestamptz
    and created_at<(p_end+1)::timestamptz
    and voided_at is null;

  select coalesce(sum(total_amount),0) into v_expenses_total
  from public.expenses
  where created_at>=p_start::timestamptz
    and created_at<(p_end+1)::timestamptz
    and voided_at is null;

  select count(*) into v_reversals_count
  from public.admin_financial_audit
  where created_at>=p_start::timestamptz
    and created_at<(p_end+1)::timestamptz
    and action ~* '(void|revers|estorn|cancelled_with_reversal|expense_voided)';

  -- Detecta a tabela de agenda existente sem quebrar instalacoes antigas.
  if to_regclass('public.appointments') is not null then v_table:='appointments';
  elsif to_regclass('public.bookings') is not null then v_table:='bookings';
  elsif to_regclass('public.agendamentos') is not null then v_table:='agendamentos';
  elsif to_regclass('public.schedule_appointments') is not null then v_table:='schedule_appointments';
  end if;

  if v_table is not null then
    select c.column_name into v_date_col
    from information_schema.columns c
    where c.table_schema='public' and c.table_name=v_table
      and c.column_name in ('scheduled_at','start_at','starts_at','appointment_at','scheduled_date','appointment_date','date','created_at')
    order by case c.column_name
      when 'scheduled_at' then 1 when 'start_at' then 2 when 'starts_at' then 3 when 'appointment_at' then 4
      when 'scheduled_date' then 5 when 'appointment_date' then 6 when 'date' then 7 else 8 end
    limit 1;

    if v_date_col is not null then
      execute format('select count(*) from public.%I where %I >= $1::date and %I < ($2::date + 1)',v_table,v_date_col,v_date_col)
      using p_start,p_end into v_appointments_count;
    end if;
  end if;

  return jsonb_build_object(
    'period_start',p_start,'period_end',p_end,
    'sales_count',v_sales_count,
    'sales_total',v_sales_total,
    'received_total',v_received_total,
    'appointments_count',v_appointments_count,
    'expenses_total',v_expenses_total,
    'cancelled_sales',v_cancelled_sales,
    'reversals_count',v_reversals_count
  );
end $$;

revoke all on function public.admin_period_metrics_v29(date,date) from public;
grant execute on function public.admin_period_metrics_v29(date,date) to authenticated;

create or replace function public.admin_goals_progress_v29()
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  g public.management_goals%rowtype;
  m jsonb;
  current_value numeric;
  items jsonb:='[]'::jsonb;
begin
  if auth.uid() is null then raise exception 'Sessao invalida.'; end if;
  if not (public.bloco21_is_admin() or public.staff_can('finance','view') or public.staff_can('sales','view')) then raise exception 'Sem permissao para visualizar metas.'; end if;
  for g in select * from public.management_goals where active=true order by period_start desc,created_at desc loop
    m:=public.admin_period_metrics_v29(g.period_start,g.period_end);
    current_value:=coalesce((m->>g.metric_key)::numeric,0);
    items:=items||jsonb_build_array(jsonb_build_object(
      'id',g.id,'title',g.title,'metric_key',g.metric_key,'target_value',g.target_value,
      'period_start',g.period_start,'period_end',g.period_end,'active',g.active,'created_at',g.created_at,
      'current_value',current_value
    ));
  end loop;
  return items;
end $$;

revoke all on function public.admin_goals_progress_v29() from public;
grant execute on function public.admin_goals_progress_v29() to authenticated;

notify pgrst, 'reload schema';
commit;
