import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const ROOT="C:\\Projetos\\SISTEMA-DRA-ANDRESSA";
const FILE=path.join(ROOT,"supabase","functions","public-booking","index.ts");
if(!fs.existsSync(FILE)){console.error("ERRO: public-booking/index.ts não encontrado.");process.exit(1)}

const stamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
const backup=path.join(ROOT,`.backup_public_booking_cadastro_${stamp}`);
fs.mkdirSync(backup,{recursive:true});
fs.copyFileSync(FILE,path.join(backup,"index.ts"));

let src=fs.readFileSync(FILE,"utf8");

if(!src.includes("HOTFIX_PATIENT_IDENTITY_V1")){
  const re=/^([ \t]*)return\s+json\(\{\s*error:\s*['"]Ação inválida\.['"]\s*\},\s*400\s*\)/m;
  const m=re.exec(src);
  if(!m){console.error("ERRO: não achei o ponto 'Ação inválida.'");process.exit(1)}
  const I=m[1]||"    ";
  const block=`
${I}// HOTFIX_PATIENT_IDENTITY_V1
${I}if (action === 'identify' || action === 'check_existing') {
${I}  const digits = (v: unknown) => String(v ?? '').replace(/\\D/g, '')
${I}  const cpf = digits(body.cpf)
${I}  const phone = digits(body.phone)

${I}  if (action === 'identify' && (!cpf || phone.length < 8)) {
${I}    return json({ found:false, message:'Informe CPF e telefone para localizar seu cadastro com segurança.' },400)
${I}  }

${I}  if (action === 'check_existing' && !cpf && phone.length < 8) {
${I}    return json({ exists:false, message:'Informe CPF ou telefone para verificar o cadastro.' })
${I}  }

${I}  const { data:rows, error:e } = await admin.from('patients').select('id,cpf,phone,whatsapp').limit(5000)
${I}  if (e) throw e
${I}  const patients = rows ?? []

${I}  if (action === 'identify') {
${I}    const found = patients.some((p:any) => {
${I}      const phones=[digits(p.phone),digits(p.whatsapp)].filter(Boolean)
${I}      return digits(p.cpf)===cpf && phones.includes(phone)
${I}    })
${I}    return json({
${I}      found,
${I}      message: found ? 'Cadastro localizado com sucesso.' : 'Não foi possível localizar um cadastro com esse CPF e telefone.'
${I}    })
${I}  }

${I}  const cpfMatch = cpf ? patients.some((p:any)=>digits(p.cpf)===cpf) : false
${I}  const phoneMatch = phone.length>=8 ? patients.some((p:any)=>{
${I}    const phones=[digits(p.phone),digits(p.whatsapp)].filter(Boolean)
${I}    return phones.includes(phone)
${I}  }) : false
${I}  const exists = cpfMatch || phoneMatch

${I}  return json({
${I}    exists,
${I}    message: exists
${I}      ? 'Já existe um cadastro com o CPF ou telefone informado. Use a opção “Já sou paciente”.'
${I}      : 'Nenhum cadastro existente foi localizado.'
${I}  })
${I}}

`;
  src=src.slice(0,m.index)+block+src.slice(m.index);
  console.log("OK - identify/check_existing adicionados.");
}

if(!src.includes("HOTFIX_SAVE_BOOKING_CPF_V1")){
  const re=/([ \t]*)if\s*\(error\)\s*throw\s+error\s*\r?\n([ \t]*)return\s+json\(\{\s*receipt:\s*data,\s*token:\s*rawToken\s*\}\)/;
  const m=re.exec(src);
  if(m){
    const I=m[1];
    const rep=`${I}if (error) throw error

${I}// HOTFIX_SAVE_BOOKING_CPF_V1
${I}const normalizedCpf = String(body.cpf || '').replace(/\\D/g,'')
${I}if (normalizedCpf && data?.appointment_id) {
${I}  const {data:a,error:ae}=await admin.from('appointments').select('patient_id').eq('id',data.appointment_id).maybeSingle()
${I}  if(ae) throw ae
${I}  if(a?.patient_id){
${I}    const {data:p,error:pe}=await admin.from('patients').select('id,cpf').eq('id',a.patient_id).maybeSingle()
${I}    if(pe) throw pe
${I}    if(p && !String(p.cpf||'').trim()){
${I}      const {error:ue}=await admin.from('patients').update({cpf:normalizedCpf}).eq('id',p.id)
${I}      if(ue) throw ue
${I}    }
${I}  }
${I}}

${I}return json({ receipt: data, token: rawToken })`;
    src=src.slice(0,m.index)+rep+src.slice(m.index+m[0].length);
    console.log("OK - CPF automático adicionado.");
  } else {
    console.log("AVISO - não achei o retorno da action create; CPF automático não foi alterado.");
  }
}

fs.writeFileSync(FILE,src,"utf8");

console.log("Publicando public-booking...");
let r=spawnSync("powershell.exe",["-NoProfile","-Command","npx supabase functions deploy public-booking --no-verify-jwt"],{cwd:ROOT,stdio:"inherit"});
if(r.status!==0){
  console.error("ERRO NO DEPLOY. Rode manualmente:");
  console.error('cd "C:\\Projetos\\SISTEMA-DRA-ANDRESSA"');
  console.error("npx supabase functions deploy public-booking --no-verify-jwt");
  process.exit(2);
}

console.log("");
console.log("==============================================");
console.log(" HOTFIX CADASTRO AUTOAGENDAMENTO CONCLUIDO");
console.log("==============================================");
console.log("Agora: Ctrl+F5 no site e teste Criar meu cadastro.");
console.log("Backup:",backup);
