import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const ROOT = "C:\\Projetos\\SISTEMA-DRA-ANDRESSA";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const FILES = path.join(HERE, "files");

function fail(msg){
  console.error("\nERRO:", msg);
  process.exit(1);
}

function run(cmd,args,{allowFail=false}={}){
  console.log("\n>", cmd, ...args);
  const r=spawnSync(cmd,args,{cwd:ROOT,stdio:"inherit",shell:false});
  if(r.error) console.error(r.error.message);
  if(r.status!==0 && !allowFail) fail(`${cmd} falhou com codigo ${r.status}`);
  return r.status===0;
}

if(!fs.existsSync(path.join(ROOT,"package.json")) || !fs.existsSync(path.join(ROOT,"src"))){
  fail(`Projeto nao encontrado em ${ROOT}`);
}
if(!fs.existsSync(FILES)) fail("Pasta files do BLOCO 28 nao encontrada.");

const stamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
const backup=path.join(ROOT,`.backup_bloco28_${stamp}`);
fs.mkdirSync(backup,{recursive:true});

const rels=[
  "src/pages/Finance.tsx",
  "src/pages/Sales.tsx",
  "src/pages/Contracts.tsx",
  "src/pages/ReceiptVerify.tsx",
  "supabase/migrations/20260901213000_bloco28_estornos_exclusoes_seguros.sql",
];

function copyFile(src,dst){
  fs.mkdirSync(path.dirname(dst),{recursive:true});
  fs.copyFileSync(src,dst);
}

console.log("============================================================");
console.log(" BLOCO 28 - ESTORNOS E EXCLUSOES SEGURAS");
console.log("============================================================");
console.log("Backup:", backup);

for(const rel of rels){
  const target=path.join(ROOT,rel);
  const source=path.join(FILES,rel);
  if(!fs.existsSync(source)) fail(`Arquivo do bloco ausente: ${rel}`);

  if(fs.existsSync(target)){
    copyFile(target,path.join(backup,rel));
  }
  copyFile(source,target);
  console.log("OK -",rel);
}

function restore(){
  console.log("\nRestaurando arquivos anteriores...");
  for(const rel of rels){
    const saved=path.join(backup,rel);
    const target=path.join(ROOT,rel);
    if(fs.existsSync(saved)){
      copyFile(saved,target);
    }else if(rel.includes("20260901213000_bloco28")){
      try{fs.rmSync(target,{force:true})}catch{}
    }
  }
}

console.log("\nVALIDANDO BUILD...");
const npm = process.platform==="win32" ? "npm.cmd" : "npm";
const npx = process.platform==="win32" ? "npx.cmd" : "npx";

const build=spawnSync(npm,["run","build"],{cwd:ROOT,stdio:"inherit",shell:false});
if(build.status!==0){
  restore();
  fail(`BUILD FALHOU. Projeto restaurado. Backup: ${backup}`);
}

console.log("\nOK - BUILD COMPLETO.");
console.log("\nATUALIZANDO BANCO SUPABASE...");
console.log("Se o Supabase perguntar se deseja aplicar a migration, confirme Yes.");

const db=spawnSync(npx,["supabase","db","push"],{cwd:ROOT,stdio:"inherit",shell:false});
if(db.status!==0){
  console.error("\nATENCAO: o frontend ficou instalado e o BUILD passou, mas o DB PUSH falhou.");
  console.error("Nao apague os arquivos. Rode manualmente:");
  console.error(`cd "${ROOT}"`);
  console.error("npx supabase db push");
  console.error("\nMigration:");
  console.error("supabase\\migrations\\20260901213000_bloco28_estornos_exclusoes_seguros.sql");
  process.exit(2);
}

console.log("\nOK - BANCO ATUALIZADO.");

console.log("\nPUBLICANDO NO GITHUB...");
run("git",["add",
  "src/pages/Finance.tsx",
  "src/pages/Sales.tsx",
  "src/pages/Contracts.tsx",
  "src/pages/ReceiptVerify.tsx",
  "supabase/migrations/20260901213000_bloco28_estornos_exclusoes_seguros.sql"
]);

const committed=run("git",["commit","-m","Bloco 28: estornos cancelamentos e exclusoes seguras"],{allowFail:true});
if(!committed){
  console.log("Git commit nao criou novo commit (pode nao haver diferenca ou existir outra configuracao local).");
}

const pushed=run("git",["push","origin","main"],{allowFail:true});
if(!pushed){
  console.log("\nATENCAO: Git push nao foi concluido. As alteracoes continuam salvas localmente.");
  console.log("Rode depois: git push origin main");
}

console.log("");
console.log("============================================================");
console.log(" BLOCO 28 CONCLUIDO");
console.log("============================================================");
console.log("Implementado:");
console.log("- Recibo: Cancelar / estornar pagamento");
console.log("- Parcela volta automaticamente para Contas a receber");
console.log("- Recibo cancelado permanece no historico e no QR de validacao");
console.log("- Despesa sem pagamento: Excluir");
console.log("- Despesa paga: Estornar mantendo historico");
console.log("- Venda/orcamento: Cancelar com motivo");
console.log("- Venda paga: Cancelar / estornar recebimentos");
console.log("- Contrato assinado: Cancelar sem apagar assinatura/historico");
console.log("- Contrato nao assinado: opcao de excluir registro de teste");
console.log("- Auditoria: usuario, data/hora, motivo e detalhes");
console.log("- Permissoes respeitadas por modulo");
console.log("");
console.log("Backup:", backup);
console.log("");
console.log("TESTES RECOMENDADOS:");
console.log("1) Financeiro > Recibos > Cancelar / estornar");
console.log("2) Confirmar que a parcela voltou para Contas a receber");
console.log("3) Vendas > venda paga > Cancelar / estornar");
console.log("4) Despesas > testar uma nao paga e uma paga");
console.log("5) Contratos > cancelar um assinado e excluir um nao assinado de teste");
console.log("============================================================");
